const AUDIO_EXTENSIONS = /\.(mp3|m4a|aac|wav|ogg|oga|flac|opus)$/i;

function toEntry(file) {
  const name = file?.name || file?.title || file?.displayName || "Unknown";
  const uri = typeof file === "string" ? file : (file?.uri || file?.path || null);
  const isUri = typeof file === "string" || (!!uri && !(file instanceof Blob));
  const size = Number(file?.size || 0);
  const modified = Number(file?.lastModified || file?.modified || file?.dateAdded || 0);
  const id = file?.id || `${isUri ? (uri || name) : name}:${size}:${modified}`;
  const title = (file?.title || name).replace(/\.[^.]+$/, "");
  const type = file?.type || file?.mimeType || file?.mime || "audio/*";
  const path = file?.webkitRelativePath || file?.relativePath || file?.path || file?.uri || name;
  return { id, title, name, size, type, modified, path, uri: isUri ? uri : (file?.uri || null) };
}

function isAudioLike(file) {
  const name = file?.name || file?.title || file?.uri || "";
  const type = file?.type || file?.mimeType || file?.mime || "";
  return AUDIO_EXTENSIONS.test(name) || String(type).startsWith("audio/") || !!file?.uri || typeof file === "string";
}

export class LocalLibrary {
  constructor(storage) {
    this.storage = storage;
    this.entries = [];
    this.files = new Map();
  }

  async restore() {
    this.entries = await this.storage.get("local-library", []);
    const savedFiles = await this.storage.get("local-files", []);
    savedFiles.forEach(item => this.files.set(item.id, item.file || item.uri || item.path));
    this.entries = this.entries.filter(entry => this.files.has(entry.id));
    return this.entries;
  }

  async save() {
    await this.storage.set("local-library", this.entries);
  }

  async saveFiles() {
    await this.storage.set("local-files", [...this.files].map(([id, file]) => {
      if (typeof file === "string") return { id, uri: file };
      if (file && !(file instanceof Blob) && (file.uri || file.path)) return { id, uri: file.uri || file.path };
      return { id, file };
    }));
  }

  async importFiles(files) {
    const list = [...(files || [])].filter(isAudioLike);
    const imported = list.map(toEntry);

    list.forEach((file, i) => {
      const entry = imported[i];
      if (!entry) return;
      this.files.set(entry.id, (file && (file.uri || typeof file === "string")) ? (file.uri || file) : file);
    });
    await this.saveFiles();

    const byId = new Map(this.entries.map(entry => [entry.id, entry]));
    imported.forEach(entry => byId.set(entry.id, { ...(byId.get(entry.id) || {}), ...entry }));
    this.entries = [...byId.values()].sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    await this.save();
    return imported;
  }

  createPlaybackUrl(file) {
    if (typeof file === "string") return file;
    if (file && !(file instanceof Blob) && file.uri) return file.uri;
    return URL.createObjectURL(file);
  }

  async clear() {
    this.entries = [];
    this.files.clear();
    await this.storage.remove("local-library");
    await this.storage.remove("local-files");
  }

  find(id) {
    return this.entries.find(entry => entry.id === id) || null;
  }

  fileFor(id) { return this.files.get(id) || null; }
}
