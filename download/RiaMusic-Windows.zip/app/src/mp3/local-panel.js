import { appState, toggleFavorite, restorePlaylists, createPlaylist, clearMp3Played, saveMp3PlayedAsPlaylist } from "../state.js";

export class LocalPanelController {
  constructor({ source, library, elements, onPlay = () => {} }) {
    this.source = source;
    this.library = library;
    this.el = elements;
    this.onPlay = onPlay;
    this.activeTab = "songs";
  }

  async init() {
    await this.library.restore();
    await restorePlaylists();
    this.bind();
    this.setTab(this.activeTab);
    this.renderAll();
  }

  bind() {
    this.el.addFolder?.addEventListener("click", async () => { await this.importFolder(); this.setTab("songs"); });
    this.el.railPlaylist?.addEventListener("click", () => this.setTab("playlists"));
    this.el.tabs?.forEach(tab => tab.addEventListener("click", () => this.setTab(tab.dataset.tab)));
    this.el.clearPlayed?.addEventListener("click", async () => {
      await clearMp3Played();
      this.renderPlayed();
    });
    this.el.savePlayed?.addEventListener("click", async () => {
      if (!(appState.mp3Played || []).length) return;
      const name = (typeof prompt === "function") ? prompt("Nama playlist:", "Diputar") : null;
      if (!name) return;
      try {
        await saveMp3PlayedAsPlaylist(name.trim() || "Diputar");
        this.renderPlaylists();
        this.setTab("playlists");
      } catch {}
    });
  }

  setTab(name) {
    const tab = name || "songs";
    this.activeTab = tab;
    this.el.tabs?.forEach(b => b.classList.toggle("is-active", b.dataset.tab === tab));
    this.el.panes?.forEach(p => p.classList.toggle("is-active", p.dataset.pane === tab));
    if (tab === "played") this.renderPlayed();
    if (tab === "playlists") this.renderPlaylists();
    if (tab === "songs") this.renderLibrary();
  }

  async importFolder() {
    try {
      const result = await this.source.pickFolder();
      const files = result?.files || (Array.isArray(result) ? result : []);
      if (!files?.length) { this.renderLibrary(); return; }
      await this.library.importFiles(files);
      this.renderLibrary();
    } catch (error) {
      if (error?.name !== "AbortError") {
        const list = this.el.list;
        if (list) list.innerHTML = "<p class=empty>Folder tidak dapat dibaca atau tidak ada lagu terdeteksi.</p>";
      }
    }
  }

  renderAll() {
    this.renderLibrary();
    this.renderPlayed();
    this.renderPlaylists();
  }

  renderLibrary() {
    const list = this.el.list;
    if (!list) return;
    list.replaceChildren();
    if (!this.library.entries.length) {
      list.innerHTML = "<p class=empty>Belum ada lagu lokal. Tekan + untuk memilih folder dan mendeteksi lagu otomatis.</p>";
      return;
    }
    for (const entry of this.library.entries) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "local-track";
      row.dataset.localId = entry.id;
      row.innerHTML = `<img class="list-icon" src="./src/assets/ria-music.svg" alt=""><span class="local-copy"><strong></strong><small></small></span><span class="fav-toggle" data-local-fav aria-label="Favorite">${appState.favorites.some(x=>x.id===entry.id)?"★":"☆"}</span>`;
      row.querySelector("strong").textContent = entry.title || entry.name;
      row.querySelector("small").textContent = entry.path || entry.uri || "";
      row.addEventListener("click", () => this.onPlay(entry));
      row.querySelector("[data-local-fav]").addEventListener("click", event => {
        event.stopPropagation();
        toggleFavorite({ ...entry, type: "local" }).then(() => {
          event.currentTarget.textContent = appState.favorites.some(x => x.id === entry.id) ? "★" : "☆";
        });
      });
      list.append(row);
    }
  }

  renderPlayed() {
    const list = this.el.playedList;
    if (!list) return;
    list.replaceChildren();
    const rows = appState.mp3Played || [];
    const saveBtn = this.el.savePlayed;
    if (saveBtn) saveBtn.disabled = rows.length === 0;
    const clearBtn = this.el.clearPlayed;
    if (clearBtn) clearBtn.disabled = rows.length === 0;
    if (!rows.length) {
      list.innerHTML = "<p class=empty>Belum ada lagu yang diputar.</p>";
      return;
    }
    for (const entry of rows) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "local-track played-track";
      row.innerHTML = `<img class="list-icon" src="./src/assets/ria-music.svg" alt=""><span class="local-copy"><strong></strong><small></small></span>`;
      row.querySelector("strong").textContent = entry.title || entry.name || "Lagu";
      row.querySelector("small").textContent = entry.path || entry.uri || "MP3 lokal";
      row.addEventListener("click", () => this.onPlay(entry));
      list.append(row);
    }
  }

  renderPlaylists() {
    const wrap = this.el.playlistCards;
    if (!wrap) return;
    wrap.replaceChildren();
    const playlists = appState.playlists || [];
    if (!playlists.length) {
      const empty = document.createElement("div");
      empty.className = "playlist-card playlist-card-empty";
      empty.innerHTML = `<strong>Belum ada playlist</strong><small>Simpan lagu yang diputar sebagai playlist, atau buat dari sini.</small><button type="button" class="playlist-create" data-create-playlist>Buat playlist</button>`;
      empty.querySelector("[data-create-playlist]")?.addEventListener("click", () => this.createNewPlaylist());
      wrap.append(empty);
      return;
    }
    for (const pl of playlists) {
      const card = document.createElement("div");
      card.className = "playlist-card";
      const count = Array.isArray(pl.items) ? pl.items.length : 0;
      card.innerHTML = `<span class="playlist-card-icon">♫</span><span class="playlist-card-copy"><strong></strong><small>${count} lagu</small></span>`;
      card.querySelector("strong").textContent = pl.name || "Playlist";
      wrap.append(card);
    }
    const create = document.createElement("button");
    create.type = "button";
    create.className = "playlist-card playlist-card-create";
    create.innerHTML = `<span class="playlist-card-icon">+</span><span class="playlist-card-copy"><strong>Buat playlist</strong><small>Playlist baru</small></span>`;
    create.addEventListener("click", () => this.createNewPlaylist());
    wrap.append(create);
  }

  async createNewPlaylist() {
    const name = (typeof prompt === "function") ? prompt("Nama playlist baru:", "Playlist Baru") : null;
    if (!name) return;
    try {
      await createPlaylist(name.trim() || "Playlist Baru");
      this.renderPlaylists();
    } catch {}
  }
}
