import { IndexedDbStorage } from "./storage/indexed-db-storage.js";
import { BrowserFileSource } from "./storage/browser-file-source.js?v=refactor2";
import { LocalLibrary } from "./mp3/local-library.js";
import { LocalPanelController } from "./mp3/local-panel.js?v=thumbs1";

// Metadata memakai IndexedDB; preferensi kecil tetap bisa memakai localStorage.
export const storage = new IndexedDbStorage();
export const localLibrary = new LocalLibrary(storage);
window.__riaLocalLibrary = localLibrary;
export const fileSource = new BrowserFileSource();
export const localPanel = (elements, onPlay) => new LocalPanelController({
  source: fileSource,
  library: localLibrary,
  elements,
  onPlay
});

export async function initLocalData() {
  await localLibrary.restore();
  return localLibrary;
}
