import * as uds from "./storage/user-data-storage.js";
import { IndexedDbStorage } from "./storage/indexed-db-storage.js";

const legacy = new IndexedDbStorage();
export const appState = { favorites: [], recent: [], playlists: [], mp3Played: [] };

let migrated = false;

async function migrateLegacy() {
  if (migrated) return;
  migrated = true;
  try {
    // favorites
    const favFile = await uds.readJson("Favorite.json", null);
    if (favFile == null) {
      const oldFav = await legacy.get("favorites", null);
      if (Array.isArray(oldFav)) await uds.writeJson("Favorite.json", oldFav);
    }
    // recent
    const recentFile = await uds.readJson("recent.json", null);
    if (recentFile == null) {
      const oldRecent = await legacy.get("recent", null);
      if (Array.isArray(oldRecent)) await uds.writeJson("recent.json", oldRecent);
    }
    // mp3-played
    const playedFile = await uds.readJson("mp3-played.json", null);
    if (playedFile == null) {
      const oldPlayed = await legacy.get("mp3-played", null);
      if (Array.isArray(oldPlayed)) await uds.writeJson("mp3-played.json", oldPlayed);
    }
    // playlists: migrate to individual files in playlist/
    const idx = await uds.readJson("playlist/_index.json", null);
    const hasIndex = Array.isArray(idx) && idx.length > 0;
    const ls = await uds.list("playlist");
    const hasFiles = ls && Array.isArray(ls.files) && ls.files.some(f => /\.json$/i.test(f) && f !== "_index.json");
    if (!hasIndex && !hasFiles) {
      const oldPlaylists = await legacy.get("playlists", null);
      if (Array.isArray(oldPlaylists) && oldPlaylists.length) {
        const ids = [];
        for (const pl of oldPlaylists) {
          if (!pl || typeof pl !== "object") continue;
          const id = String(pl.id || ("pl-" + Date.now() + "-" + Math.random().toString(36).slice(2,7)));
          const item = { ...pl, id };
          await uds.writeJson("playlist/" + id + ".json", item);
          ids.push(id);
        }
        if (ids.length) await uds.writeJson("playlist/_index.json", ids);
      }
    }
  } catch {}
}

async function readPlaylistDir() {
  // try listing native dir
  const ls = await uds.list("playlist");
  let files = (ls && Array.isArray(ls.files)) ? ls.files.filter(f => /\.json$/i.test(f) && f !== "_index.json" && f !== "index.json") : [];
  if (!files.length) {
    const idx = await uds.readJson("playlist/_index.json", []);
    if (Array.isArray(idx) && idx.length) files = idx.map(id => String(id).endsWith(".json") ? String(id) : (String(id) + ".json"));
  }
  const out = [];
  for (const f of files) {
    const pl = await uds.readJson("playlist/" + f, null);
    if (pl && typeof pl === "object") out.push(pl);
  }
  // newest first by createdAt if present, else keep order
  out.sort((a,b) => (b.createdAt||0) - (a.createdAt||0));
  return out;
}

async function writeAllPlaylists(playlists) {
  const list = Array.isArray(playlists) ? playlists : [];
  // write each
  const ids = [];
  for (const pl of list) {
    if (!pl || typeof pl !== "object") continue;
    const id = String(pl.id || ("pl-" + Date.now() + "-" + Math.random().toString(36).slice(2,7)));
    const item = { ...pl, id };
    await uds.writeJson("playlist/" + id + ".json", item);
    ids.push(id);
  }
  await uds.writeJson("playlist/_index.json", ids);
  // attempt to remove stale playlist files not in ids (best-effort)
  try {
    const ls = await uds.list("playlist");
    const files = (ls && Array.isArray(ls.files)) ? ls.files.filter(f => /\.json$/i.test(f) && f !== "_index.json" && f !== "index.json") : [];
    for (const f of files) {
      const fid = f.replace(/\.json$/i, "");
      if (!ids.includes(fid) && !ids.includes(f)) {
        try { await uds.remove("playlist/" + f); } catch {}
      }
    }
  } catch {}
  // also remove ids that disappeared? handled above by index; old files removed if listable
  return list;
}

export async function restoreState() {
  await migrateLegacy();
  appState.favorites = await uds.readJson("Favorite.json", []);
  if (!Array.isArray(appState.favorites)) appState.favorites = [];
  appState.recent = await uds.readJson("recent.json", []);
  if (!Array.isArray(appState.recent)) appState.recent = [];
  appState.playlists = await readPlaylistDir();
  if (!Array.isArray(appState.playlists)) appState.playlists = [];
  appState.mp3Played = await uds.readJson("mp3-played.json", []);
  if (!Array.isArray(appState.mp3Played)) appState.mp3Played = [];
  return appState;
}

export async function saveState() {
  await uds.writeJson("Favorite.json", Array.isArray(appState.favorites) ? appState.favorites : []);
  await uds.writeJson("recent.json", Array.isArray(appState.recent) ? appState.recent : []);
  await writeAllPlaylists(Array.isArray(appState.playlists) ? appState.playlists : []);
  await uds.writeJson("mp3-played.json", Array.isArray(appState.mp3Played) ? appState.mp3Played : []);
}

export async function restorePlaylists() {
  await migrateLegacy();
  appState.playlists = await readPlaylistDir();
  if (!Array.isArray(appState.playlists)) appState.playlists = [];
  return appState.playlists;
}

export async function savePlaylists() {
  await writeAllPlaylists(Array.isArray(appState.playlists) ? appState.playlists : []);
  return appState.playlists;
}

export async function createPlaylist(name, items = []) {
  const playlist = {
    id: `pl-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: name || "Playlist Baru",
    items: Array.isArray(items) ? items : [],
    createdAt: Date.now()
  };
  appState.playlists = [playlist, ...(appState.playlists || [])];
  await savePlaylists();
  return playlist;
}

export async function addMp3Played(item) {
  if (!item) return appState.mp3Played;
  const entry = { ...item, type: "local" };
  const key = entry.id || entry.title;
  appState.mp3Played = [entry, ...(appState.mp3Played || []).filter(x => (x.id || x.title) !== key)].slice(0, 100);
  await uds.writeJson("mp3-played.json", appState.mp3Played);
  return appState.mp3Played;
}

export async function clearMp3Played() {
  appState.mp3Played = [];
  await uds.writeJson("mp3-played.json", appState.mp3Played);
  return appState.mp3Played;
}

export async function saveMp3PlayedAsPlaylist(name) {
  const items = (appState.mp3Played || []).map(x => ({ ...x, type: "local" }));
  return createPlaylist(name || "Diputar", items);
}

export async function toggleFavorite(item) {
  const key = item.id || item.title;
  const found = appState.favorites.findIndex(x => (x.id || x.title) === key);
  if (found >= 0) appState.favorites.splice(found, 1);
  else appState.favorites.unshift(item);
  await uds.writeJson("Favorite.json", appState.favorites);
}

export async function addRecent(item) {
  const key = item.id || item.title;
  appState.recent = [item, ...appState.recent.filter(x => (x.id || x.title) !== key)].slice(0, 12);
  await uds.writeJson("recent.json", appState.recent);
}
