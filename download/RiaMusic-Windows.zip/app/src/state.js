import { IndexedDbStorage } from "./storage/indexed-db-storage.js";

const storage = new IndexedDbStorage();
export const appState = { favorites: [], recent: [], playlists: [], mp3Played: [] };

export async function restoreState() {
  appState.favorites = await storage.get("favorites", []);
  appState.recent = await storage.get("recent", []);
  appState.playlists = await storage.get("playlists", []);
  appState.mp3Played = await storage.get("mp3-played", []);
  return appState;
}

export async function saveState() {
  await storage.set("favorites", appState.favorites);
  await storage.set("recent", appState.recent);
  await storage.set("playlists", appState.playlists);
  await storage.set("mp3-played", appState.mp3Played);
}

export async function restorePlaylists() {
  appState.playlists = await storage.get("playlists", []);
  return appState.playlists;
}

export async function savePlaylists() {
  await storage.set("playlists", appState.playlists);
  return appState.playlists;
}

export async function createPlaylist(name, items = []) {
  const playlist = {
    id: `pl:${Date.now()}:${Math.random().toString(36).slice(2, 7)}`,
    name: name || "Playlist Baru",
    items: Array.isArray(items) ? items : [],
    createdAt: Date.now()
  };
  appState.playlists = [playlist, ...(appState.playlists || [])];
  await savePlaylists();
  return playlist;
}

export async function addMp3Played(item) {
  if (!item) return appState.mp3Played;
  const entry = { ...item, type: "local" };
  const key = entry.id || entry.title;
  appState.mp3Played = [entry, ...(appState.mp3Played || []).filter(x => (x.id || x.title) !== key)].slice(0, 100);
  await storage.set("mp3-played", appState.mp3Played);
  return appState.mp3Played;
}

export async function clearMp3Played() {
  appState.mp3Played = [];
  await storage.set("mp3-played", appState.mp3Played);
  return appState.mp3Played;
}

export async function saveMp3PlayedAsPlaylist(name) {
  const items = (appState.mp3Played || []).map(x => ({ ...x, type: "local" }));
  return createPlaylist(name || "Diputar", items);
}

export async function toggleFavorite(item) {
  const key = item.id || item.title;
  const found = appState.favorites.findIndex(x => (x.id || x.title) === key);
  if (found >= 0) appState.favorites.splice(found, 1);
  else appState.favorites.unshift(item);
  await saveState();
}

export async function addRecent(item) {
  const key = item.id || item.title;
  appState.recent = [item, ...appState.recent.filter(x => (x.id || x.title) !== key)].slice(0, 12);
  await saveState();
}
