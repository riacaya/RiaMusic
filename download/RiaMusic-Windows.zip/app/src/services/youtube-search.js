const PIPED_APIS = [
  "https://api.piped.private.coffee",
  "https://pipedapi.kavin.rocks",
  "https://pipedapi.adminforge.de",
  "https://pipedapi.in.projectsegfau.lt",
  "https://pipedapi.darkness.services",
  "https://pipedapi.drgns.space",
  "https://pipedapi.leptons.xyz",
  "https://piped-api.garudalinux.org"
];

function extractVideoId(url = "") {
  try {
    const s = String(url);
    if (!s) return "";
    const m = s.match(/[?&]v=([^&/]+)/);
    if (m) return m[1];
    const m2 = s.match(/\/watch\/([^?&/]+)/);
    if (m2) return m2[1];
  } catch {}
  return "";
}

function normalizeThumb(item) {
  const t = item?.thumbnail || item?.thumbnailUrl || (Array.isArray(item?.thumbnails) && item.thumbnails.length ? (item.thumbnails[item.thumbnails.length - 1]?.url || item.thumbnails[0]?.url) : "");
  return t || "";
}

function normalizeItems(data, limit) {
  const items = Array.isArray(data?.items) ? data.items : (Array.isArray(data) ? data : []);
  const out = [];
  for (const it of items) {
    if (!it) continue;
    if (it.type && it.type !== "stream" && it.type !== "video") continue;
    const videoId = extractVideoId(it.url || it.id || "");
    if (!videoId) continue;
    out.push({
      type: "yt",
      videoId,
      title: it.title || "Video",
      desc: it.uploaderName || it.uploader || "YouTube",
      uploader: it.uploaderName || it.uploader || "",
      image: normalizeThumb(it),
      duration: it.duration ?? null
    });
    if (out.length >= limit) break;
  }
  return out;
}

async function fetchSearch(base, q) {
  const url = `${base}/search?q=${encodeURIComponent(q)}&filter=videos`;
  const res = await fetch(url, { headers: { "Accept": "application/json" } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  return data;
}

export async function searchYouTube(query, { limit = 20 } = {}) {
  const q = String(query || "").trim();
  if (!q) return [];
  let lastErr = null;
  let hadSuccess = false;
  for (const base of PIPED_APIS) {
    try {
      const data = await fetchSearch(base, q);
      hadSuccess = true;
      const out = normalizeItems(data, limit);
      if (out.length > 0) return out;
      // if empty, try other instances before giving up
    } catch (e) {
      lastErr = e;
    }
  }
  if (hadSuccess) return [];
  const msg = (lastErr && lastErr.message) ? lastErr.message : "Pencarian YouTube gagal";
  throw new Error(`Gagal mencari (${msg}). Periksa koneksi internet.`);
}
