const PIPED_APIS = [
  "https://pipedapi.kavin.rocks",
  "https://pipedapi.adminforge.de",
  "https://api.piped.private.coffee",
  "https://pipedapi.in.projectsegfau.lt"
];

function extractVideoId(url = "") {
  try {
    const s = String(url);
    if (s.includes("v=")) {
      const m = s.match(/[?&]v=([^&]+)/);
      if (m) return m[1];
    }
    // paths like /watch?v=... or /v/...
    const m2 = s.match(/\/watch\?v=([^&/]+)/) || s.match(/[?&]v=([^&/]+)/);
    if (m2) return m2[1];
  } catch {}
  return "";
}

function normalizeThumb(item) {
  const t = item?.thumbnail || item?.thumbnailUrl || (Array.isArray(item?.thumbnails) ? item.thumbnails[item.thumbnails.length - 1]?.url : "");
  return t || "";
}

export async function searchYouTube(query, { limit = 20 } = {}) {
  const q = String(query || "").trim();
  if (!q) return [];
  let lastErr = null;
  for (const base of PIPED_APIS) {
    try {
      const url = `${base}/search?q=${encodeURIComponent(q)}&filter=videos`;
      const res = await fetch(url, { headers: { "Accept": "application/json" } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const items = Array.isArray(data?.items) ? data.items : (Array.isArray(data) ? data : []);
      const out = [];
      for (const it of items) {
        if (it?.type && it.type !== "stream" && it.type !== "video") continue;
        const videoId = extractVideoId(it?.url || it?.id || "");
        if (!videoId) continue;
        out.push({
          type: "yt",
          videoId,
          title: it?.title || "Video",
          desc: it?.uploaderName || it?.uploader || "YouTube",
          uploader: it?.uploaderName || it?.uploader || "",
          image: normalizeThumb(it),
          duration: it?.duration ?? null
        });
        if (out.length >= limit) break;
      }
      return out;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("Pencarian YouTube gagal");
}
