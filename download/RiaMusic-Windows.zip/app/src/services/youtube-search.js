const PIPED_APIS = [
  "https://api.piped.private.coffee",
  "https://pipedapi.ducks.party",
  "https://pipedapi.kavin.rocks",
  "https://pipedapi.adminforge.de",
  "https://pipedapi.in.projectsegfau.lt",
  "https://pipedapi.darkness.services",
  "https://pipedapi.drgns.space",
  "https://pipedapi.leptons.xyz",
  "https://piped-api.garudalinux.org"
];

let extraApis = null;
async function getApis() {
  let discovered = [];
  try {
    if (!extraApis) {
      const ctrl = (typeof AbortController !== "undefined") ? new AbortController() : null;
      const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch {} }, 5000) : null;
      try {
        const res = await fetch("https://piped-instances.kavin.rocks/", { headers: { "Accept": "application/json" }, signal: ctrl ? ctrl.signal : undefined });
        if (res.ok) {
          const list = await res.json();
          if (Array.isArray(list)) {
            extraApis = list.map(x => (x && (x.api_url || x.apiUrl)) || "").filter(u => /^https?:\/\//.test(u)).map(u => u.replace(/\/+$/, ""));
          }
        }
      } finally { if (timer) clearTimeout(timer); }
    }
    discovered = Array.isArray(extraApis) ? extraApis : [];
  } catch {}
  const seen = new Set();
  const out = [];
  for (const u of [...PIPED_APIS, ...discovered]) {
    if (!u || seen.has(u)) continue;
    seen.add(u);
    out.push(u);
  }
  return out;
}

function extractVideoId(url = "") {
  try {
    const s = String(url);
    if (!s) return "";
    const m = s.match(/[?&]v=([^&/]+)/);
    if (m) return m[1];
    const m2 = s.match(/\/watch\/([^?&/]+)/);
    if (m2) return m2[1];
  } catch {}
  return "";
}

function normalizeThumb(item) {
  const t = item?.thumbnail || item?.thumbnailUrl || (Array.isArray(item?.thumbnails) && item.thumbnails.length ? (item.thumbnails[item.thumbnails.length - 1]?.url || item.thumbnails[0]?.url) : "");
  return t || "";
}

function normalizeItems(data, limit) {
  const items = Array.isArray(data?.items) ? data.items : (Array.isArray(data) ? data : []);
  const out = [];
  for (const it of items) {
    if (!it) continue;
    if (it.type && it.type !== "stream" && it.type !== "video") continue;
    const videoId = extractVideoId(it.url || it.id || it.videoId || "");
    if (!videoId) continue;
    out.push({
      type: "yt",
      videoId,
      title: it.title || "Video",
      desc: it.uploaderName || it.uploader || it.author || "YouTube",
      uploader: it.uploaderName || it.uploader || it.author || "",
      image: normalizeThumb(it),
      duration: it.duration ?? it.lengthSeconds ?? null
    });
    if (out.length >= limit) break;
  }
  return out;
}

async function fetchSearch(base, q) {
  const url = `${base}/search?q=${encodeURIComponent(q)}&filter=videos`;
  const ctrl = (typeof AbortController !== "undefined") ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch {} }, 10000) : null;
  try {
    const res = await fetch(url, { headers: { "Accept": "application/json" }, signal: ctrl ? ctrl.signal : undefined });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function searchYouTube(query, { limit = 20 } = {}) {
  const q = String(query || "").trim();
  if (!q) return [];
  let lastErr = null;
  let hadSuccess = false;
  let tried = 0;
  const apis = await getApis();
  const maxTry = Math.min(apis.length, 10);
  for (let i = 0; i < maxTry; i++) {
    const base = apis[i];
    try {
      tried++;
      const data = await fetchSearch(base, q);
      hadSuccess = true;
      const out = normalizeItems(data, limit);
      if (out.length > 0) return out;
      // if empty, try other instances before giving up
    } catch (e) {
      lastErr = e;
    }
  }
  if (hadSuccess) throw new Error(`Tidak ada hasil dari ${tried} server pencarian untuk kata kunci ini. Coba kata kunci lain.`);
  const msg = (lastErr && lastErr.message) ? lastErr.message : "Pencarian YouTube gagal";
  throw new Error(`Gagal mencari (${msg}, dicoba ${tried} server). Pastikan terhubung internet & gunakan versi aplikasi terbaru.`);
}
