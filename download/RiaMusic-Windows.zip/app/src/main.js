import { initLocalData, fileSource, localLibrary } from "./app.js";
import { renderHeader, renderPlayer, renderRail, renderRailHeader } from "./ui/player-view.js?v=20261120p";
import { LibraryPanel } from "./panels/library-panel.js?v=20261120p";
import { OverlayManager } from "./panels/overlay-manager.js?v=20261120p";
import { QueuePanel } from "./ui/queue-panel.js";
import { AudioPlayer } from "./player/audio-player.js";
import { loadMediaData } from "./data/data-loader.js?v=20261120p";
import { getWeather } from "./services/weather-service.js?v=weather2";
import { restoreState, addRecent, addMp3Played } from "./state.js";
import { preferences } from "./preferences.js";
import * as bridge from "./bridge/ria-bridge.js";
import * as queue from "./queue.js?v=20261120p";

const isApk = bridge.platform() === "android";
if (isApk) document.body.classList.add("is-apk");
if (bridge.platform() === "windows") document.body.classList.add("is-windows");

renderRailHeader(document.querySelector("#rail-header"));
renderRail(document.querySelector("#app-rail"));
renderHeader(document.querySelector("#app-header"));
renderPlayer(document.querySelector("#player-stage"));
const fallbackArtwork = "./src/assets/ria-music.svg";
const cover = document.querySelector("#cover");
const sourceIcon = document.querySelector("#sourceIcon");
cover.onerror = () => { if (cover.src !== fallbackArtwork) cover.src = fallbackArtwork; };
sourceIcon.onerror = () => { if (sourceIcon.src !== fallbackArtwork) sourceIcon.src = fallbackArtwork; };

const fullscreenButton = document.createElement("button");
fullscreenButton.className = "ctrl"; fullscreenButton.dataset.action = "fullscreen"; fullscreenButton.textContent = "⛶";
const videoProgress = document.createElement("input");
videoProgress.type = "range"; videoProgress.id = "videoProgress"; videoProgress.min = "0"; videoProgress.max = "1000"; videoProgress.value = "0"; videoProgress.title = "Posisi video";
const videoTime = document.createElement("span");
videoTime.id = "videoTime"; videoTime.textContent = "00:00 / 00:00";
document.querySelector("#player-stage .controls .vol").before(videoProgress, videoTime, fullscreenButton);
const formatTime = seconds => { if (!Number.isFinite(seconds) || seconds < 0) return "00:00"; const m = Math.floor(seconds / 60), s = Math.floor(seconds % 60); return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`; };
videoProgress.addEventListener("input", () => { const video = document.querySelector("#video"); if (video.duration) video.currentTime = (Number(videoProgress.value) / 1000) * video.duration; });
document.querySelector("#video").addEventListener("timeupdate", () => { const video = document.querySelector("#video"); if (video.duration) { videoProgress.value = String(Math.round(video.currentTime / video.duration * 1000)); videoTime.textContent = `${formatTime(video.currentTime)} / ${formatTime(video.duration)}`; } });
const syncAudioProgress = () => { const audio = document.querySelector("#audio"); if (audio.duration) { videoProgress.value = String(Math.round(audio.currentTime / audio.duration * 1000)); videoTime.textContent = `${formatTime(audio.currentTime)} / ${formatTime(audio.duration)}`; } };
document.querySelector("#audio").addEventListener("timeupdate", syncAudioProgress);
document.querySelector("#audio").addEventListener("loadedmetadata", () => { videoProgress.value = "0"; videoTime.textContent = `00:00 / ${formatTime(document.querySelector("#audio").duration)}`; });
document.querySelector("#streamAudio").addEventListener("playing", () => { videoProgress.value = "0"; videoTime.textContent = "LIVE"; });
document.addEventListener("fullscreenchange", () => { fullscreenButton.textContent = document.fullscreenElement ? "×" : "⛶"; });

await initLocalData();
await restoreState();
await queue.restoreQueue();

const setStageMode = mode => document.querySelector("#player-stage").dataset.mode = mode;
const remember = (key, value) => preferences.set(key, value);
const recall = (key, fallback) => preferences.value(key, fallback);
const savePlaybackPosition = media => { if (media?.src) remember("position", { src: media.src, time: media.currentTime || 0 }); };
document.querySelector("#audio").addEventListener("timeupdate", () => savePlaybackPosition(document.querySelector("#audio")));
document.querySelector("#streamAudio").addEventListener("timeupdate", () => savePlaybackPosition(document.querySelector("#streamAudio")));
document.querySelector("#video").addEventListener("timeupdate", () => savePlaybackPosition(document.querySelector("#video")));

let sourceInfoTimer;
function showSourceInfo(item) { const box = document.querySelector("#sourceInfo"); document.querySelector("#sourceIcon").src = item.image || fallbackArtwork; document.querySelector("#sourceTitle").textContent = item.title || "Video"; document.querySelector("#sourceDesc").textContent = item.desc || ""; box.classList.remove("source-hidden"); clearTimeout(sourceInfoTimer); sourceInfoTimer = setTimeout(() => box.classList.add("source-hidden"), 4500); }
function setArtwork(item) { const image = item?.image || fallbackArtwork; document.querySelector("#cover").src = image; document.querySelector("#backdrop").style.backgroundImage = "url(\"" + image + "\")"; }
const lastMode = recall("mode", "youtube");
setStageMode(["youtube", "radio", "audio", "video"].includes(lastMode) ? lastMode : "youtube");
const closeLibraryPanel = () => { if (!matchMedia("(min-width:900px)").matches) library.close(); };
function switchSource(mode) {
  document.querySelector("#audio").pause(); document.querySelector("#streamAudio").pause(); document.querySelector("#video").pause();
  document.querySelector("#audio").removeAttribute("src"); document.querySelector("#streamAudio").removeAttribute("src"); document.querySelector("#video").removeAttribute("src"); document.querySelector("#yt").src = "";
  setStageMode(mode); remember("mode", mode);
}

getWeather().then(w => { document.querySelector("#city").textContent = w.city; document.querySelector("#weatherText").textContent = `Weather ${w.temperature}°C`; }).catch(() => { document.querySelector("#city").textContent = "Location unavailable"; document.querySelector("#weatherText").textContent = "Weather unavailable"; });

const mediaData = await loadMediaData();
const audioPlayer = new AudioPlayer(document.querySelector("#audio"), { playButton: document.querySelector("#play"), bars: [...document.querySelectorAll("#eq span")] });

const radioRecorderMod = await import("./player/radio-recorder.js?v=20261120p");
radioRecorderMod.loadRecordings().catch(() => {});
window.__riaRadioRecorder = radioRecorderMod;

function formatRecTime(ms) { const s = Math.max(0, Math.floor(ms / 1000)); const m = Math.floor(s / 60); const ss = String(s % 60).padStart(2, "0"); return `${m}:${ss}`; }
function updateRecordUi(state) {
  const st = state || radioRecorderMod.getState();
  const b = document.querySelector('[data-action="record"]');
  if (b) { b.classList.toggle("recording", !!st.recording); b.textContent = st.recording ? "\u25A0" : "\u25CF"; }
  if (st.recording) {
    document.querySelector("#desc").textContent = `Merekam radio${st.station ? " • " + st.station : ""} • ${formatRecTime(st.elapsedMs)}`;
  }
}
radioRecorderMod.subscribe((st) => {
  updateRecordUi(st);
  if (!st.recording) {
    const recs = st.recordings || [];
    if (recs[0] && recs[0].createdAt && Date.now() - recs[0].createdAt < 5000) {
      if (recs[0].ok) {
        const where = recs[0].path || recs[0].uri || "Download/RiaMusic";
        document.querySelector("#desc").textContent = `Tersimpan: ${where}`;
      } else if (recs[0].blobUrl) {
        document.querySelector("#desc").textContent = "Rekaman siap diputar (tersimpan sementara di app).";
      } else {
        document.querySelector("#desc").textContent = "Rekaman selesai.";
      }
    }
  }
});

function prepareRadioAnalyser() {
  const streamEl = document.querySelector("#streamAudio");
  const bars = [...document.querySelectorAll("#eq span")];
  radioRecorderMod.prepare(streamEl, bars);
}

const activeAudio = () => document.querySelector("#player-stage").dataset.mode === "radio" ? document.querySelector("#streamAudio") : document.querySelector("#audio");
document.querySelector("#volume").value = recall("volume", document.querySelector("#volume").value);
document.querySelector("#volume").addEventListener("input", event => { activeAudio().volume = Number(event.target.value) / 100; remember("volume", event.target.value); });
document.querySelector("#mute").addEventListener("click", () => { const audio = activeAudio(); audio.muted = !audio.muted; document.querySelector("#mute").textContent = audio.muted ? "\u{1F507}" : "\u{1F50A}"; });

// Radio record (quick toggle)
document.querySelector("#player-stage").addEventListener("click", async event => {
  const b = event.target.closest('[data-action="record"]');
  if (!b) return;
  event.stopPropagation();
  const st = radioRecorderMod.getState();
  if (st.recording) { radioRecorderMod.stop(); return; }
  if (document.querySelector("#player-stage").dataset.mode !== "radio") {
    document.querySelector("#desc").textContent = "Putar stasiun radio terlebih dahulu untuk merekam.";
    return;
  }
  prepareRadioAnalyser();
  const stationName = (document.querySelector("#title")?.textContent || "").trim();
  const res = await radioRecorderMod.start(stationName);
  if (res && res.ok === false) document.querySelector("#desc").textContent = res.error || "Perekaman tidak dapat dimulai.";
}, { capture: true });

// Components
const queueHeaderEl = document.querySelector("#queue-header");
const useQueueHeader = typeof matchMedia === "function" && matchMedia("(min-width:900px)").matches;
const queuePanel = new QueuePanel(document.querySelector("#queue-panel"), useQueueHeader ? queueHeaderEl : null);
const library = new LibraryPanel(document.querySelector("#panel-root"));
library.mediaData = mediaData;
const overlays = new OverlayManager(document.querySelector("#overlay-root"));

function localPanelFile(id) { return window.__riaLocalLibrary?.fileFor(id) || null; }

async function playLocalEntry(entry) {
  const localFile = localPanelFile(entry.id) || entry.uri || entry.path || entry.src || null;
  if (!localFile) { document.querySelector("#desc").textContent = "File MP3 tidak tersedia. Pilih ulang dari tombol +"; return; }
  await addRecent({ ...entry, type: "local" });
  await addMp3Played({ ...entry, type: "local" });
  switchSource("audio"); remember("media", { type: "local", id: entry.id, title: entry.title });
  setArtwork({});
  document.querySelector("#title").textContent = entry.title || entry.name;
  document.querySelector("#desc").textContent = entry.queueLabel || entry.channel || "Audio Lokal";
  audioPlayer.playFile(localFile).catch(() => { document.querySelector("#desc").textContent = "MP3 tidak dapat diputar"; });
}

async function playRadioItem(item) {
  await addRecent({ ...item, type: "radio" }); remember("media", { type: "radio", item });
  setArtwork(item);
  switchSource("radio");
  const radio = document.querySelector("#streamAudio");
  prepareRadioAnalyser();
  radioRecorderMod.resume();
  radio.src = item.stream; radio.load();
  radio.volume = Number(document.querySelector("#volume").value) / 100;
  radio.autoplay = true;
  radio.play().then(() => document.querySelector("#player-stage").classList.add("playing")).catch(() => { document.querySelector("#player-stage").classList.remove("playing"); document.querySelector("#desc").textContent = "Tekan tombol Play untuk memulai radio"; });
  document.querySelector("#title").textContent = item.title;
  document.querySelector("#desc").textContent = item.desc || "";
  document.querySelector("#sourceInfo").classList.add("source-hidden");
}

async function playYoutubeItem(item) {
  await addRecent({ ...item, type: "yt" }); remember("media", { type: "yt", item });
  setArtwork(item);
  switchSource("youtube");
  document.querySelector("#yt").src = `https://www.youtube.com/embed/videoseries?list=${encodeURIComponent(item.playlist)}&autoplay=1&playsinline=1&controls=1`;
  document.querySelector("#title").textContent = item.title;
  document.querySelector("#desc").textContent = item.desc || "";
  showSourceInfo(item);
}

async function playLocalVideoItem(item) {
  let file = item.file || item;
  // if item comes from queue/playlist as metadata, try to resolve from storage
  if (!file.uri && !file.size && (item.name || item.title)) {
    const files = await (await import("./app.js")).storage.get("local-videos", []);
    const rows = Array.isArray(files) ? files : [];
    const key = item.id || item.name || item.title;
    file = rows.find(v => (v.id && key && v.id === key) || (v.name && (v.name === item.name || v.name === item.title))) || item;
  }
  await addRecent({ id: `video:${file.name || item.name}:${file.size || 0}`, title: file.title || file.name || item.title, desc: "Video lokal", type: "local-video" });
  remember("media", { type: "local-video", title: file.name || item.title });
  switchSource("video"); setArtwork({});
  const video = document.querySelector("#video");
  const uri = file.uri || file.path || file.src;
  if (uri) {
    video.src = bridge.resolvePlayableUri(uri);
  } else if (file instanceof Blob) {
    video.src = URL.createObjectURL(file);
  } else {
    document.querySelector("#title").textContent = file.name || item.title || "Video"; document.querySelector("#desc").textContent = "File video tidak tersedia"; showSourceInfo({ title: file.name || item.title || "Video", desc: "File video tidak tersedia" });
    return;
  }
  video.play().catch(() => {});
  document.querySelector("#title").textContent = file.name || item.title || "Video"; document.querySelector("#desc").textContent = "Video lokal"; showSourceInfo({ title: file.name || item.title || "Video", desc: "Video lokal" });
}

async function playQueueItem(index, item) {
  if (!item) return;
  queue.setIndex(index);
  if (item.type === "local") await playLocalEntry(item);
  else if (item.type === "radio") await playRadioItem(item);
  else if (item.type === "yt" || item.type === "youtube") await playYoutubeItem(item);
  else if (item.type === "local-video") await playLocalVideoItem(item);
  else await playRadioItem(item);
  closeLibraryPanel();
}

queuePanel.onPlayAt = (i, item) => playQueueItem(i, item);
queuePanel.mount();

// Events from library panel
document.querySelector("#panel-root").addEventListener("play-queue-index", (e) => {
  const i = e.detail?.index ?? 0;
  const item = queue.getItems()[i];
  if (item) playQueueItem(i, item);
});

// Overlays: record / menu navigation
document.querySelector("#overlay-root").addEventListener("record-radio", () => document.querySelector('[data-action="record"]')?.click());
document.querySelector("#overlay-root").addEventListener("play-url", (event) => { playUrl(event.detail); overlays.close(); });
document.querySelector("#overlay-root").addEventListener("open-library", (event) => { library.open(event.detail || "mp3"); });
document.querySelector("#overlay-root").addEventListener("open-overlay", (event) => { overlays.open(event.detail); });
document.querySelector("#overlay-root").addEventListener("add-local", () => { library.addLocalFolder(); });
document.querySelector("#overlay-root").addEventListener("open-queue", () => { document.querySelector("#queue-panel")?.classList.add("show"); });

// Legacy/direct events still used
document.querySelector("#panel-root").addEventListener("play-url", (event) => playUrl(event.detail));

function playUrl(url) {
  document.querySelector("#audio").pause(); document.querySelector("#streamAudio").pause(); document.querySelector("#video").pause();
  const isVideo = /\.(mp4|webm|ogv|mov|m3u8)(\?|#|$)/i.test(url) || /(youtube\.com|youtu\.be|\/video(?:\/|\?|$))/i.test(url);
  if (isVideo) { switchSource("video"); const video = document.querySelector("#video"); video.src = url; video.load(); video.play().catch(() => {}); document.querySelector("#title").textContent = "Video URL"; document.querySelector("#desc").textContent = url; showSourceInfo({ title: "Video URL", desc: url }); }
  else { switchSource("audio"); const audio = document.querySelector("#streamAudio"); audio.src = url; audio.load(); audio.play().catch(() => {}); document.querySelector("#title").textContent = "Audio URL"; document.querySelector("#desc").textContent = url; }
}

// Controls: next/prev/shuffle using queue
document.querySelector("#player-stage").addEventListener("click", event => {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const mode = document.querySelector("#player-stage").dataset.mode;
  if (button.dataset.action === "toggle" && mode === "video") {
    event.stopImmediatePropagation(); const video = document.querySelector("#video");
    if (video.paused) video.play().catch(() => {}); else video.pause();
  }
  if (button.dataset.action === "mute" && mode === "video") {
    event.stopImmediatePropagation(); const video = document.querySelector("#video");
    video.muted = !video.muted; button.textContent = video.muted ? "🔇" : "🔊";
  }
  if (button.dataset.action === "repeat") {
    const media = mode === "video" ? document.querySelector("#video") : activeAudio();
    media.loop = !media.loop; button.style.color = media.loop ? "var(--accent)" : "";
  }
  if (button.dataset.action === "fullscreen") {
    event.stopImmediatePropagation();
    if (document.fullscreenElement) document.exitFullscreen?.();
    else document.querySelector("#player-stage").requestFullscreen?.();
  }
  const items = queue.getItems();
  if ((button.dataset.action === "next" || button.dataset.action === "previous" || button.dataset.action === "shuffle") && items.length) {
    event.stopImmediatePropagation();
    let idx = queue.getIndex();
    if (button.dataset.action === "shuffle") idx = Math.floor(Math.random() * items.length);
    else idx = (idx + (button.dataset.action === "next" ? 1 : -1) + items.length) % items.length;
    playQueueItem(idx, items[idx]);
  }
}, { capture: true });

document.querySelector("#video").addEventListener("play", () => { if (document.querySelector("#player-stage").dataset.mode === "video") document.querySelector("#play").textContent = "❚❚"; });
document.querySelector("#video").addEventListener("pause", () => { if (document.querySelector("#player-stage").dataset.mode === "video") document.querySelector("#play").textContent = "▶"; });
let videoIdleTimer;
const showVideoControls = () => { const stage = document.querySelector("#player-stage"); if (stage.dataset.mode !== "video") return; stage.classList.remove("video-idle"); clearTimeout(videoIdleTimer); videoIdleTimer = setTimeout(() => { if (!document.querySelector("#video").paused) stage.classList.add("video-idle"); }, 3500); };
document.querySelector("#player-stage").addEventListener("mousemove", showVideoControls);
document.querySelector("#player-stage").addEventListener("touchstart", showVideoControls, { passive: true });
document.querySelector("#video").addEventListener("pause", () => document.querySelector("#player-stage").classList.remove("video-idle"));
document.querySelector("#video").addEventListener("loadedmetadata", () => { videoProgress.value = "0"; videoTime.textContent = `00:00 / ${formatTime(document.querySelector("#video").duration)}`; });
document.querySelector("#play").addEventListener("click", event => { if (document.querySelector("#player-stage").dataset.mode !== "radio") return; event.stopImmediatePropagation(); const radio = document.querySelector("#streamAudio"); if (radio.paused) radio.play().then(() => document.querySelector("#player-stage").classList.add("playing")).catch(() => {}); else radio.pause(); }, { capture: true });
document.querySelector("#streamAudio").addEventListener("playing", () => { document.querySelector("#play").textContent = "❚❚"; });
document.querySelector("#streamAudio").addEventListener("pause", () => { document.querySelector("#play").textContent = "▶"; });
document.querySelector("#audio").addEventListener("play", () => document.querySelector("#player-stage").classList.add("playing"));
document.querySelector("#audio").addEventListener("pause", () => document.querySelector("#player-stage").classList.remove("playing"));
document.querySelector("#streamAudio").addEventListener("play", () => document.querySelector("#player-stage").classList.add("playing"));
document.querySelector("#streamAudio").addEventListener("playing", () => document.querySelector("#player-stage").classList.add("playing"));
document.querySelector("#streamAudio").addEventListener("pause", () => document.querySelector("#player-stage").classList.remove("playing"));
document.querySelector("#streamAudio").addEventListener("ended", () => document.querySelector("#player-stage").classList.remove("playing"));
document.querySelector("#streamAudio").addEventListener("error", () => { document.querySelector("#desc").textContent = "Radio stream unavailable"; document.querySelector("#play").textContent = "▶"; });

document.documentElement.dataset.theme = recall("theme", "mystic");
const firstLaunch = !preferences.value("initialized", false);
if (firstLaunch) preferences.set("initialized", true);

// Header / navigation
function toggleQueueMobile() {
  if (matchMedia("(min-width:900px)").matches) return; // desktop always visible
  document.querySelector("#queue-panel").classList.toggle("show");
}
function openRailDrawer() {
  document.body.classList.add("rail-drawer-open");
}
function closeRailDrawer() {
  document.body.classList.remove("rail-drawer-open");
}
function toggleRailDrawer() {
  document.body.classList.toggle("rail-drawer-open");
}
function handleNavClick(event) {
  if (event.target.closest("[data-action=open-rail]")) { toggleRailDrawer(); return; }
  if (event.target.closest("[data-action=close-rail]")) { closeRailDrawer(); return; }
  if (event.target.closest("[data-action=rail-toggle]")) { document.body.classList.toggle("rail-expanded"); return; }
  if (event.target.closest("[data-action=add-local]")) { closeRailDrawer(); library.addLocalFolder(); return; }
  if (event.target.closest("[data-action=queue]")) { closeRailDrawer(); toggleQueueMobile(); return; }
  if (event.target.closest("[data-action=menu]")) { overlays.open("menu"); return; }
  const lib = event.target.closest("[data-open='library']");
  if (lib) { const tab = lib.dataset.tab || "mp3"; remember("libTab", tab); closeRailDrawer(); library.open(tab); return; }
  const ov = event.target.closest("[data-open='overlay']");
  if (ov) { closeRailDrawer(); overlays.open(ov.dataset.overlay); return; }
}
document.querySelector("#app-header").addEventListener("click", handleNavClick);
document.querySelector("#app-rail")?.addEventListener("click", handleNavClick);
document.querySelector("#rail-header")?.addEventListener("click", handleNavClick);
document.addEventListener("click", (e) => {
  if (document.body.classList.contains("rail-drawer-open") && !e.target.closest("#app-rail") && !e.target.closest("[data-action=open-rail]")) {
    closeRailDrawer();
  }
});

// Initial state: daftar putar selalu dimuat dari recent (instalasi pertama boleh kosong)
library.close();
const recentQueue = (appState.recent || []).map(x => ({ ...x }));
if (recentQueue.length) {
  queue.setQueue(recentQueue, 0);
  playQueueItem(0, recentQueue[0]);
} else {
  queue.clearQueue();
}









