import { createPlaylist } from "./state.js";
import { IndexedDbStorage } from "./storage/indexed-db-storage.js";

const queueStorage = new IndexedDbStorage();
let items = [];
let index = -1;
const listeners = new Set();

function sanitizeItem(x) {
  if (!x || typeof x !== "object") return x;
  const o = { ...x };
  try { if (o.file && (typeof Blob !== "undefined" && o.file instanceof Blob)) delete o.file; } catch {}
  if (typeof o.src === "string" && o.src.startsWith("blob:")) delete o.src;
  if (typeof o.uri === "string" && o.uri.startsWith("blob:")) delete o.uri;
  return o;
}
function persist() { try { queueStorage.set("queue", { items: items.map(sanitizeItem), index }); } catch {} }
function notify() { listeners.forEach(fn => { try { fn(getState()); } catch {} }); }

export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function getState() { return { items: [...items], index }; }
export function getItems() { return items; }
export function getIndex() { return index; }
export function getCurrent() { return index >= 0 ? items[index] : null; }

export async function restoreQueue() {
  try {
    const saved = await queueStorage.get("queue", null);
    if (saved && Array.isArray(saved.items)) {
      items = saved.items;
      index = Number.isInteger(saved.index) ? saved.index : (items.length ? 0 : -1);
      if (index < 0 || index >= items.length) index = items.length ? 0 : -1;
    }
  } catch {}
  notify();
  return getState();
}

export function setQueue(newItems = [], newIndex = -1, opts = {}) {
  items = Array.isArray(newItems) ? [...newItems] : [];
  index = (newIndex >= 0 && newIndex < items.length) ? newIndex : (items.length ? 0 : -1);
  persist();
  notify();
  return getState();
}

export function clearQueue() {
  items = [];
  index = -1;
  persist();
  notify();
}

export function setIndex(i) {
  if (i >= 0 && i < items.length) index = i;
  persist();
  notify();
}

export async function saveQueueAsPlaylist(name) {
  if (!items.length) return null;
  const playlistItems = items.map(x => ({ ...x }));
  return createPlaylist(name || "Daftar Putar", playlistItems);
}
