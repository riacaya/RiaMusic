/**
 * Kontrak penyimpanan lokal.
 * Adapter browser, Android, dan Windows nantinya mengikuti API yang sama.
 */
export class StorageContract {
  async get(key, fallback = null) { throw new Error("get() belum diimplementasikan"); }
  async set(key, value) { throw new Error("set() belum diimplementasikan"); }
  async remove(key) { throw new Error("remove() belum diimplementasikan"); }
}
