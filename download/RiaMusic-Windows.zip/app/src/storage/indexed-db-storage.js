import { StorageContract } from "./storage-contract.js";

export class IndexedDbStorage extends StorageContract {
  constructor(name = "riaMusicLibrary", store = "library") {
    super();
    this.name = name;
    this.store = store;
    this.dbPromise = null;
  }

  open() {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(this.name, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(this.store)) {
          request.result.createObjectStore(this.store);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return this.dbPromise;
  }

  async get(key, fallback = null) {
    try {
      const db = await this.open();
      return await new Promise((resolve, reject) => {
        const request = db.transaction(this.store, "readonly")
          .objectStore(this.store).get(key);
        request.onsuccess = () => resolve(request.result ?? fallback);
        request.onerror = () => reject(request.error);
      });
    } catch {
      return fallback;
    }
  }

  async set(key, value) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const request = db.transaction(this.store, "readwrite")
        .objectStore(this.store).put(value, key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async remove(key) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const request = db.transaction(this.store, "readwrite")
        .objectStore(this.store).delete(key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
}
