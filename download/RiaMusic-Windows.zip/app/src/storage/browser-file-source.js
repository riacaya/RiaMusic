import { FileSource } from "./file-source.js";
import * as bridge from "../bridge/ria-bridge.js";

const AUDIO_EXTENSIONS = /\.(mp3|m4a|aac|wav|ogg|oga|flac|opus)$/i;

function normalizeNativeItems(result) {
  if (!result) return [];
  if (Array.isArray(result)) return result.filter(Boolean);
  const items = result.files || result.items || [];
  return Array.isArray(items) ? items.filter(Boolean) : [];
}

function waitForPickResult(timeoutMs = 120000) {
  return new Promise(resolve => {
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      window.removeEventListener("ria-pick-result", onEvent);
      clearTimeout(timer);
      resolve(value);
    };
    const onEvent = (e) => finish(e?.detail ?? null);
    const timer = setTimeout(() => finish(null), timeoutMs);
    window.addEventListener("ria-pick-result", onEvent, { once: true });
  });
}

async function resolveMaybePending(result) {
  if (!result) return null;
  if (result.pending) {
    const evt = await waitForPickResult();
    if (evt) return evt;
    // fallback: bridge may store last result
    const b = bridge.getBridge();
    if (b?.takePendingPickResult) {
      try {
        const v = b.takePendingPickResult();
        return typeof v === "string" ? JSON.parse(v) : v;
      } catch { return null; }
    }
    return null;
  }
  return result;
}

export class BrowserFileSource extends FileSource {
  bridge() { return bridge; }
  capabilities() { return bridge.capabilities(); }
  async requestMediaPermission(kind = "audio") { return bridge.requestMediaPermission(kind); }
  async getMediaPermissionStatus(kind = "audio") { return bridge.getMediaPermissionStatus(kind); }
  async scanMedia(kind = "audio") { return bridge.scanMedia(kind); }

  async pickVideoFolder() {
    // Input dialog is more reliable in localhost, embedded browsers, and APK WebViews.
    return new Promise(resolve => {
      const input = document.createElement("input");
      input.type = "file"; input.multiple = true; input.accept = "video/*,.mp4,.webm,.ogv,.mov";
      input.webkitdirectory = true;
      input.onchange = () => resolve([...input.files]);
      input.click();
    });
  }

  async pickJson() {
    return new Promise(resolve => {
      const input = document.createElement("input");
      input.type = "file"; input.accept = "application/json,.json";
      input.onchange = () => resolve(input.files?.[0] || null);
      input.click();
    });
  }

  async pickFiles() {
    const native = await resolveMaybePending(await bridge.pickAudio());
    if (native) return normalizeNativeItems(native);
    if (window.Capacitor?.Plugins?.RiaFilePicker) {
      return (await window.Capacitor.Plugins.RiaFilePicker.pick({ type: "audio/*" })).files || [];
    }
    return new Promise(resolve => {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = true;
      input.accept = "audio/*";
      input.onchange = () => resolve([...input.files]);
      input.click();
    });
  }

  async pickVideoFiles() {
    const native = await resolveMaybePending(await bridge.pickVideo());
    if (native) return normalizeNativeItems(native);
    if (window.Capacitor?.Plugins?.RiaFilePicker) {
      return (await window.Capacitor.Plugins.RiaFilePicker.pick({ type: "video/*" })).files || [];
    }
    return new Promise(resolve => {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = true;
      input.accept = "video/*,.mp4,.webm,.ogv,.mov";
      input.onchange = () => resolve([...input.files]);
      input.click();
    });
  }

  async pickFolder() {
    const native = await resolveMaybePending(await bridge.pickFolder("audio"));
    if (native) {
      const files = normalizeNativeItems(native);
      return { files, handle: null, name: native.name || "Music", native: true };
    }
    if (window.showDirectoryPicker && !bridge.isNativeShell() && window.location.protocol !== "http:") {
      const directory = await window.showDirectoryPicker({ mode: "read" });
      const files = [];
      const walk = async (handle, path = "") => {
        for await (const entry of handle.values()) {
          if (entry.kind === "file" && AUDIO_EXTENSIONS.test(entry.name)) {
            const file = await entry.getFile();
            Object.defineProperty(file, "webkitRelativePath", { value: path ? `${path}/${entry.name}` : entry.name });
            files.push(file);
          } else if (entry.kind === "directory") {
            await walk(entry, path ? `${path}/${entry.name}` : entry.name);
          }
        }
      };
      await walk(directory);
      return { files, handle: directory, name: directory.name };
    }

    return new Promise(resolve => {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = true;
      input.accept = "audio/*";
      if (!bridge.isNativeShell()) input.webkitdirectory = true;
      input.onchange = () => resolve({ files: [...input.files], handle: null, name: "Music" });
      input.click();
    });
  }
}
