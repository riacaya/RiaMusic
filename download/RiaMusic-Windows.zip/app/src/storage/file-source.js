export class FileSource {
  async pickFiles() { throw new Error("pickFiles() belum diimplementasikan"); }
  async pickFolder() { throw new Error("pickFolder() belum diimplementasikan"); }
}
