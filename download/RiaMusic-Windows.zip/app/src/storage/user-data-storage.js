import * as bridge from "../bridge/ria-bridge.js";
import { IndexedDbStorage } from "./indexed-db-storage.js";

const fallback = new IndexedDbStorage("riaMusicLibrary", "library");

function normPath(p) {
  return String(p || "").replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+/g, "/");
}

async function nativeRead(path) {
  const b = bridge.getBridge();
  if (!b?.userDataRead) return null;
  try {
    const r = await b.userDataRead(path);
    if (!r) return null;
    if (r.ok === false) return r;
    return r;
  } catch { return null; }
}
async function nativeWrite(path, content) {
  const b = bridge.getBridge();
  if (!b?.userDataWrite) return null;
  try { return await b.userDataWrite(path, content); } catch { return null; }
}
async function nativeList(path) {
  const b = bridge.getBridge();
  if (!b?.userDataList) return null;
  try { return await b.userDataList(path); } catch { return null; }
}
async function nativeDelete(path) {
  const b = bridge.getBridge();
  if (!b?.userDataDelete) return null;
  try { return await b.userDataDelete(path); } catch { return null; }
}

function fbKey(path) { return "ud:" + normPath(path); }

export async function readText(path, fallbackValue = null) {
  const p = normPath(path);
  const nr = await nativeRead(p);
  if (nr && nr.ok) return typeof nr.content === "string" ? nr.content : fallbackValue;
  if (nr && nr.ok === false && !nr.unsupported) {
    // native says missing/error - try fallback store too? prefer native as source of truth when supported
    const v = await fallback.get(fbKey(p), null);
    return typeof v === "string" ? v : fallbackValue;
  }
  const v = await fallback.get(fbKey(p), null);
  return typeof v === "string" ? v : fallbackValue;
}

export async function readJson(path, fallbackValue = null) {
  const txt = await readText(path, null);
  if (txt == null) return fallbackValue;
  try { return JSON.parse(txt); } catch { return fallbackValue; }
}

export async function writeText(path, content) {
  const p = normPath(path);
  const text = String(content ?? "");
  const nw = await nativeWrite(p, text);
  // always mirror to fallback for portability/fallback reads
  try { await fallback.set(fbKey(p), text); } catch {}
  return nw && nw.ok ? nw : { ok: true, path: p, mirrored: true };
}

export async function writeJson(path, value) {
  return writeText(path, JSON.stringify(value, null, 2));
}

export async function remove(path) {
  const p = normPath(path);
  const nd = await nativeDelete(p);
  try { await fallback.remove(fbKey(p)); } catch {}
  return nd || { ok: true };
}

export async function list(dir = "") {
  const p = normPath(dir);
  const nl = await nativeList(p);
  if (nl && nl.ok && (Array.isArray(nl.files) || Array.isArray(nl.dirs))) {
    return { ok: true, files: nl.files || [], dirs: nl.dirs || [] };
  }
  // fallback: scan indexeddb-backed keys with prefix ud:<dir/?>
  // IndexedDbStorage doesn't support listing; best-effort not possible here.
  return nl || { ok: false, files: [], dirs: [], unsupported: true };
}

export async function readJsonDir(dir, fallbackValue = []) {
  const ls = await list(dir);
  const files = (ls && ls.files ? ls.files : []).filter(f => /\.json$/i.test(f));
  if (!files.length) return fallbackValue;
  const out = [];
  for (const f of files) {
    const p = normPath(dir ? (dir + "/" + f) : f);
    const obj = await readJson(p, null);
    if (obj != null) out.push(obj);
  }
  return out.length ? out : fallbackValue;
}
