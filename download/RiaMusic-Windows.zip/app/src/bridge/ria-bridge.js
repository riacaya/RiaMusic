/**
 * Abstraksi bridge native untuk shell Kotlin (Android) dan WebView2 (Windows).
 * Native shell diharapkan mengekspos `window.RiaBridge`.
 * Semua metode bersifat opsional; caller harus cek capabilities/fallback.
 */

export function getBridge() {
  if (typeof window !== "undefined" && window.RiaBridge) return window.RiaBridge;
  return null;
}

export function platform() {
  const b = getBridge();
  if (b?.platform) return typeof b.platform === "function" ? b.platform() : b.platform;
  if (typeof window !== "undefined" && window.Capacitor?.getPlatform) return window.Capacitor.getPlatform();
  return "web";
}

export function capabilities() {
  const b = getBridge();
  const base = {
    scanMedia: false,
    pickAudio: true,
    pickVideo: true,
    pickFolder: !!(typeof window !== "undefined" && window.showDirectoryPicker),
    persistUri: false,
    userData: false,
  };
  if (!b) return base;
  const caps = typeof b.capabilities === "function" ? b.capabilities() : b.capabilities;
  return { ...base, ...(caps || {}), native: true, userData: !!(caps?.userData || b.userDataRead) };
}

function parseMaybeJson(value) {
  if (typeof value === "string") {
    try { return JSON.parse(value); } catch { return value; }
  }
  return value;
}

export async function requestMediaPermission(kind = "audio") {
  const b = getBridge();
  if (b?.requestMediaPermission) return parseMaybeJson(await b.requestMediaPermission(kind));
  return { granted: true, mode: "web" };
}

export async function getMediaPermissionStatus(kind = "audio") {
  const b = getBridge();
  if (b?.getMediaPermissionStatus) return parseMaybeJson(await b.getMediaPermissionStatus(kind));
  return { granted: null, mode: "web" };
}

export async function scanMedia(kind = "audio") {
  const b = getBridge();
  if (b?.scanMedia) return parseMaybeJson(await b.scanMedia(kind));
  return { items: [], supported: false };
}

export async function pickAudio() {
  const b = getBridge();
  if (b?.pickAudio) return parseMaybeJson(await b.pickAudio());
  if (b?.pickFiles) return parseMaybeJson(await b.pickFiles({ type: "audio/*", kind: "audio" }));
  return null;
}

export async function pickVideo() {
  const b = getBridge();
  if (b?.pickVideo) return parseMaybeJson(await b.pickVideo());
  if (b?.pickVideoFiles) return parseMaybeJson(await b.pickVideoFiles());
  if (b?.pickFiles) return parseMaybeJson(await b.pickFiles({ type: "video/*", kind: "video" }));
  return null;
}

export async function pickFolder(kind = "audio") {
  const b = getBridge();
  if (b?.pickFolder) return parseMaybeJson(await b.pickFolder({ kind }));
  return null;
}

export function resolvePlayableUri(uri) {
  const b = getBridge();
  if (!uri) return uri;
  if (b?.resolvePlayableUri) return b.resolvePlayableUri(uri);
  if (typeof window !== "undefined" && window.Capacitor?.convertFileSrc) {
    try { return window.Capacitor.convertFileSrc(uri); } catch { return uri; }
  }
  return uri;
}

export async function saveRecording(name, dataUrl) {
  const b = getBridge();
  if (b?.saveRecording) return await b.saveRecording(name, dataUrl);
  if (typeof window !== "undefined" && window.Capacitor?.Plugins?.RiaFilePicker?.saveRecording) {
    return await window.Capacitor.Plugins.RiaFilePicker.saveRecording({ name, data: dataUrl });
  }
  return null;
}

export function isNativeShell() {
  return !!getBridge() || !!(typeof window !== "undefined" && window.Capacitor?.isNativePlatform?.());
}

export async function userDataRead(path) {
  const b = getBridge();
  if (!b?.userDataRead) return { ok: false, unsupported: true };
  try { return parseMaybeJson(await b.userDataRead(path)); } catch (e) { return { ok: false, error: String(e) }; }
}
export async function userDataWrite(path, content) {
  const b = getBridge();
  if (!b?.userDataWrite) return { ok: false, unsupported: true };
  try { return parseMaybeJson(await b.userDataWrite(path, content)); } catch (e) { return { ok: false, error: String(e) }; }
}
export async function userDataList(path = "") {
  const b = getBridge();
  if (!b?.userDataList) return { ok: false, unsupported: true, files: [], dirs: [] };
  try { return parseMaybeJson(await b.userDataList(path)); } catch (e) { return { ok: false, error: String(e) }; }
}
export async function userDataDelete(path) {
  const b = getBridge();
  if (!b?.userDataDelete) return { ok: false, unsupported: true };
  try { return parseMaybeJson(await b.userDataDelete(path)); } catch (e) { return { ok: false, error: String(e) }; }
}
