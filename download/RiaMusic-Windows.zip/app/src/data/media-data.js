export const ART={
  logo:"./src/assets/ria-music.svg",
  mp3:"./src/assets/ria-music.svg"
};

export const RADIO=[
  ["Love Live","The most beautiful love songs","https://streaming.radiostreamlive.com/radiolovelive_devices"],
  ["Love CH","Chill / love music","http://bigrradio.cdnstream1.com/5207_128"],
  ["MagicFM","Adult contemporary","https://live.magicfm.ro/magicfm.aacp"],
  ["ZenoFM 1","Radio Stream","https://stream.zeno.fm/0r0xa792kwzuv"],
  ["Romantic","Romantic & ballad","https://streaming.azerion.tech/az-station"]
].map(([title,desc,stream])=>({title,desc,stream,image:ART.mp3}));

export const YT=[
  ["Dwilight","Future dreams","PLlpExeVG5pORYbNtf2rZVmeWAWj2Mtd4b"],
  ["Aesthetic","With you","PLw7o1jK9MQHCZwTNFrfovy6kwA3XaZYM7"],
  ["OverThink","When you go","PLw7o1jK9MQHBcsFHRIdsKgW7hq18Tpg-I"],
  ["IndoRia","Past and memories","PLw7o1jK9MQHBvRwEzmdwkQ6gzySn5YcmI"]
].map(([title,desc,playlist])=>({title,desc,playlist,image:ART.mp3}));

export const EQ_PRESETS={flat:[0,0,0],pop:[2,3,2],rock:[5,1,4],jazz:[3,2,1]};
