export async function loadMediaData(){
  const [radio,youtube]=await Promise.all([fetch("./data/radio.json").then(r=>r.json()),fetch("./data/youtube.json").then(r=>r.json())]);
  const fallback="./src/assets/ria-music.svg";
  return {radio:radio.map(item=>({...item,image:item.image||fallback})),youtube:youtube.map(item=>({...item,image:item.image||fallback}))};
}
