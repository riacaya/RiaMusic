export async function loadMediaData(){
  const v = "v=20261120w";
  const [radio,youtube]=await Promise.all([fetch(`./data/radio.json?${v}`).then(r=>r.json()),fetch(`./data/youtube.json?${v}`).then(r=>r.json())]);
  const fallback="./src/assets/ria-music.svg";
  return {radio:radio.map(item=>({...item,image:item.image||fallback})),youtube:youtube.map(item=>({...item,image:item.image||fallback}))};
}

















