const views={yt:["YT Playlist","Daftar playlist YouTube"],radio:["Radio","Siaran radio pilihan"],favorites:["Favorites","Lagu yang disimpan"],recent:["Recent","Riwayat lagu terakhir"],settings:["Settings","Tema, bahasa, volume, dan equalizer"],about:["About","Informasi aplikasi RiaMusic"]};
export function renderPanelView(name){
  const [title,description]=views[name]||["Panel",""];
  const logo=typeof __RIA_LOGO__!=="undefined"?__RIA_LOGO__:new URL("../assets/ria-music.svg",import.meta.url).href;
  const content=name==="about"?`<img class="about-logo" src="${logo}" alt="RiaMusic logo"><div class="about-copy"><p>RiaMusic</p><p>After The Silent</p><p>+6282338013610</p><p>riacaya99@gmail.com</p><p>Versi 1.0.0</p></div>`:`<p>${description}</p><p class="panel-hint">Panel ini sudah dipisahkan dan siap dihubungkan ke data RiaMusic asli.</p>`;
  return `<div class="panel-shell${name==="about"?" about-panel":""}"><header><button data-close>&larr;</button><h2>${title}</h2><span></span></header><div class="body-card">${content}</div></div>`;
}
