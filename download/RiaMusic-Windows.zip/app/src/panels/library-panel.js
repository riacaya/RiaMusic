import { localLibrary, fileSource, storage } from "../app.js";
import { RADIO, YT } from "../data/media-data.js";
import { appState, toggleFavorite, saveState, savePlaylists } from "../state.js";
import { setQueue, addToQueue } from "../queue.js?v=20261120u";
import { searchYouTube } from "../services/youtube-search.js?v=20261120u";

export class LibraryPanel {
  constructor(root) {
    this.root = root;
    this.mediaData = { youtube: null, radio: null };
    this.activeTab = "mp3";
    this.manageMode = false;
    this.selected = new Set();
    this.ytSearchQuery = "";
    this.ytSearchResults = null; // null = not searched, [] = no results
    this.ytSearching = false;
    this.ytSearchError = "";
  }

  async ensureMediaLists() {
    if (!Array.isArray(this.mediaData.youtube)) {
      const stored = await storage.get("user-youtube", null);
      this.mediaData.youtube = Array.isArray(stored) ? stored : YT.map(x => ({ ...x }));
    }
    if (!Array.isArray(this.mediaData.radio)) {
      const stored = await storage.get("user-radio", null);
      this.mediaData.radio = Array.isArray(stored) ? stored : RADIO.map(x => ({ ...x }));
    }
  }

  async open(tab = "mp3") {
    this.activeTab = tab || "mp3";
    this.manageMode = false;
    this.selected.clear();
    this.root.classList.add("show");
    await this.ensureMediaLists();
    this.renderShell();
    await this.renderTab(this.activeTab, { syncQueue: true });
  }

  close() {
    this.root.classList.remove("show");
    this.root.replaceChildren();
  }

  renderShell() {
    const tabs = [
      ["yt", "YT"], ["radio", "Radio"], ["mp3", "MP3"], ["video", "Video"], ["favorites", "Favorit"], ["recent", "Recent"]
    ];
    const active = this.activeTab || "mp3";
    const isDesktop = typeof window !== "undefined" && window.matchMedia("(min-width:900px)").matches;
    const header = isDesktop
      ? `<header class="library-header"><span></span><h2><span class="panel-title-icon" aria-hidden="true">☰</span>Playlist</h2><button type="button" data-close class="panel-close" aria-label="Tutup">&times;</button></header>`
      : `<header class="library-header"><button type="button" data-close class="panel-close" aria-label="Kembali">&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">☰</span>Playlist</h2><span></span></header>`;
    this.root.innerHTML = `<div class="panel-shell library-shell">${header}<div class="library-tabs">${tabs.map(([id, label]) => `<button class="lib-tab${id === active ? " is-active" : ""}" data-lib-tab="${id}">${label}</button>`).join("")}</div><div class="library-toolbar" data-lib-toolbar></div><div class="library-body" data-lib-body></div></div>`;
    this.root.querySelector("[data-close]")?.addEventListener("click", () => this.close());
    this.root.querySelectorAll("[data-lib-tab]").forEach(btn => btn.addEventListener("click", () => this.selectTab(btn.dataset.libTab)));
  }
  renderToolbar(count = 0) {
    const bar = this.root.querySelector("[data-lib-toolbar]");
    if (!bar) return;
    const t = this.activeTab;
    const bulk = this.manageMode;
    let html = "";
    if (!bulk) {
      if (t === "yt" || t === "radio" || t === "video") html += `<button type="button" class="tool-btn" data-tool="add">+ Tambah</button>`;
      if (t === "recent") html += `<button type="button" class="tool-btn danger" data-tool="clear-all">Bersihkan semua</button>`;
      if (count > 0) html += `<button type="button" class="tool-btn" data-tool="bulk">Pilih</button>`;
    } else {
      html += `<button type="button" class="tool-btn danger" data-tool="delete" ${this.selected.size ? "" : "disabled"}>Hapus (${this.selected.size})</button>`;
      html += `<button type="button" class="tool-btn" data-tool="select-all">Pilih semua</button>`;
      html += `<button type="button" class="tool-btn" data-tool="cancel">Batal</button>`;
    }
    bar.innerHTML = html || `<span class="tool-hint"></span>`;
    bar.querySelector("[data-tool=add]")?.addEventListener("click", () => this.onAdd());
    bar.querySelector("[data-tool=bulk]")?.addEventListener("click", async () => { this.manageMode = true; this.selected.clear(); await this.renderTab(t); });
    bar.querySelector("[data-tool=cancel]")?.addEventListener("click", async () => { this.manageMode = false; this.selected.clear(); await this.renderTab(t); });
    bar.querySelector("[data-tool=select-all]")?.addEventListener("click", async () => { await this.selectAllCurrent(); });
    bar.querySelector("[data-tool=delete]")?.addEventListener("click", async () => { await this.deleteSelected(); });
    bar.querySelector("[data-tool=clear-all]")?.addEventListener("click", async () => { await this.clearAllRecent(); });
  }

  async selectTab(tab) {
    this.activeTab = tab;
    this.manageMode = false;
    this.selected.clear();
    this.root.querySelectorAll("[data-lib-tab]").forEach(b => b.classList.toggle("is-active", b.dataset.libTab === tab));
    await this.renderTab(tab, { syncQueue: true });
  }

  body() { return this.root.querySelector("[data-lib-body]"); }

  async renderTab(tab, opts = {}) {
    const body = this.body();
    if (!body) return;
    if (tab === "yt" || tab === "radio") return this.renderMediaTab(tab, body, opts);
    if (tab === "mp3") return this.renderMp3Tab(body, opts);
    if (tab === "video") return this.renderVideoTab(body, opts);
    if (tab === "favorites" || tab === "recent") return this.renderSavedTab(tab, body, opts);
  }

  keyFor(item, i) { return String(item?.id || item?.title || item?.name || i); }

  toggleSelect(key) {
    if (this.selected.has(key)) this.selected.delete(key); else this.selected.add(key);
    this.renderToolbar();
  }

  async selectAllCurrent() {
    const t = this.activeTab;
    let keys = [];
    if (t === "yt" || t === "radio") keys = (this.mediaData?.[t === "radio" ? "radio" : "youtube"] || []).map((x,i)=>this.keyFor(x,i));
    else if (t === "mp3") keys = (appState.playlists || []).map((x,i)=>this.keyFor(x,i));
    else if (t === "video") { const rows = await storage.get("local-videos", []); keys = (Array.isArray(rows)?rows:[]).map((x,i)=>this.keyFor(x,i)); }
    else if (t === "favorites" || t === "recent") keys = (appState[t] || []).map((x,i)=>this.keyFor(x,i));
    const allSelected = keys.length && keys.every(k => this.selected.has(k));
    this.selected = new Set(allSelected ? [] : keys);
    await this.renderTab(t);
    this.renderToolbar();
  }

  async onAdd() {
    const t = this.activeTab;
    if (t === "video") return this.addVideos();
    if (t === "radio") return this.addRadio();
    if (t === "yt") return this.addYoutube();
  }

  async addRadio() {
    const title = (typeof prompt === "function") ? prompt("Nama radio:") : null;
    if (!title) return;
    const stream = (typeof prompt === "function") ? prompt("URL stream:") : null;
    if (!stream) return;
    const desc = (typeof prompt === "function") ? (prompt("Deskripsi (opsional):", "") || "") : "";
    await this.ensureMediaLists();
    this.mediaData.radio = [{ title: title.trim(), desc: desc.trim(), stream: stream.trim(), image: "./src/assets/ria-music.svg" }, ...(this.mediaData.radio || [])];
    await storage.set("user-radio", this.mediaData.radio);
    await this.renderTab("radio");
  }

  async addYoutube() {
    const title = (typeof prompt === "function") ? prompt("Judul playlist:") : null;
    if (!title) return;
    let playlist = (typeof prompt === "function") ? prompt("Playlist ID atau URL YouTube:") : null;
    if (!playlist) return;
    playlist = playlist.trim();
    const m = playlist.match(/[?&]list=([^&]+)/) || playlist.match(/playlist\?list=([^&]+)/);
    if (m) playlist = m[1];
    const desc = (typeof prompt === "function") ? (prompt("Deskripsi (opsional):", "") || "") : "";
    await this.ensureMediaLists();
    this.mediaData.youtube = [{ title: title.trim(), desc: desc.trim(), playlist, image: "./src/assets/ria-music.svg" }, ...(this.mediaData.youtube || [])];
    await storage.set("user-youtube", this.mediaData.youtube);
    await this.renderTab("yt");
  }

  async addVideos() {
    try {
      const picked = await fileSource.pickVideoFiles();
      const files = Array.isArray(picked) ? picked : (picked?.files || []);
      if (!files.length) return;
      const existing = await storage.get("local-videos", []);
      const byKey = new Map((Array.isArray(existing) ? existing : []).map(v => [v.id || `${v.name}:${v.size || 0}`, v]));
      for (const f of files) {
        const name = f?.name || f?.title || "Video";
        const id = f?.id || `video:${name}:${f?.size || 0}:${f?.lastModified || 0}`;
        byKey.set(id, { id, name, title: name.replace(/\.[^.]+$/, ""), size: Number(f?.size || 0), type: f?.type || "video/*", modified: Number(f?.lastModified || 0), uri: (f && !(f instanceof Blob) && (f.uri || f.path)) ? (f.uri || f.path) : (f?.uri || null), file: (f instanceof Blob || (typeof File !== "undefined" && f instanceof File)) ? f : (f?.file || null) });
      }
      await storage.set("local-videos", [...byKey.values()]);
    } catch (e) { if (e?.name !== "AbortError") console.warn("Gagal menambah video", e); }
    await this.renderTab("video");
  }

  async clearAllRecent() {
    if (!appState.recent?.length) return;
    if (typeof confirm === "function" && !confirm("Bersihkan semua riwayat?")) return;
    appState.recent = [];
    await saveState();
    await this.renderTab("recent");
  }

  async deleteOne(tab, index) {
    if (typeof confirm === "function" && !confirm("Hapus item ini?")) return;
    if (tab === "yt" || tab === "radio") {
      await this.ensureMediaLists();
      const keyName = tab === "radio" ? "radio" : "youtube";
      const storeKey = tab === "radio" ? "user-radio" : "user-youtube";
      this.mediaData[keyName] = (this.mediaData[keyName] || []).filter((_, i) => i !== index);
      await storage.set(storeKey, this.mediaData[keyName]);
    } else if (tab === "mp3") {
      appState.playlists = (appState.playlists || []).filter((_, i) => i !== index);
      await savePlaylists();
    } else if (tab === "video") {
      const rows = await storage.get("local-videos", []);
      const next = (Array.isArray(rows) ? rows : []).filter((_, i) => i !== index);
      await storage.set("local-videos", next);
    } else if (tab === "favorites") {
      appState.favorites = (appState.favorites || []).filter((_, i) => i !== index);
      await saveState();
    } else if (tab === "recent") {
      appState.recent = (appState.recent || []).filter((_, i) => i !== index);
      await saveState();
    }
    await this.renderTab(tab);
  }

  async deleteSelected() {
    if (!this.selected.size) return;
    if (typeof confirm === "function" && !confirm(`Hapus ${this.selected.size} item terpilih?`)) return;
    const t = this.activeTab;
    if (t === "yt" || t === "radio") {
      await this.ensureMediaLists();
      const keyName = t === "radio" ? "radio" : "youtube";
      const storeKey = t === "radio" ? "user-radio" : "user-youtube";
      this.mediaData[keyName] = (this.mediaData[keyName] || []).filter((x,i) => !this.selected.has(this.keyFor(x,i)));
      await storage.set(storeKey, this.mediaData[keyName]);
    } else if (t === "mp3") {
      appState.playlists = (appState.playlists || []).filter((x,i) => !this.selected.has(this.keyFor(x,i)));
      await savePlaylists();
    } else if (t === "video") {
      const rows = await storage.get("local-videos", []);
      const next = (Array.isArray(rows)?rows:[]).filter((x,i) => !this.selected.has(this.keyFor(x,i)));
      await storage.set("local-videos", next);
    } else if (t === "favorites") {
      appState.favorites = (appState.favorites || []).filter((x,i) => !this.selected.has(this.keyFor(x,i)));
      await saveState();
    } else if (t === "recent") {
      appState.recent = (appState.recent || []).filter((x,i) => !this.selected.has(this.keyFor(x,i)));
      await saveState();
    }
    this.selected.clear();
    this.manageMode = false;
    await this.renderTab(t);
  }

  async addLocalFolder() {
    try {
      const result = await fileSource.pickFolder();
      const files = result?.files || (Array.isArray(result) ? result : []);
      if (!files?.length) return;
      await localLibrary.importFiles(files);
    } catch (error) {
      if (error?.name !== "AbortError") console.warn("Gagal memuat folder lokal", error);
      return;
    }
    const rows = window.__riaLocalLibrary?.entries || [];
    setQueue(rows.map(x => ({ ...x, type: "local" })), rows.length ? 0 : -1);
  }

  fillQueueFromTab(tab) {
    if (tab === "radio") {
      const rows = this.mediaData?.radio || [];
      setQueue(rows.map(x => ({ ...x, type: "radio" })), rows.length ? 0 : -1);
    } else if (tab === "yt") {
      const rows = this.mediaData?.youtube || [];
      setQueue(rows.map(x => ({ ...x, type: "yt" })), rows.length ? 0 : -1);
    } else if (tab === "mp3") {
      // MP3 tab shows saved playlists; don't auto-fill queue on tab select
    } else if (tab === "video") {
      // filled async in renderVideoTab when listing
    } else if (tab === "favorites" || tab === "recent") {
      const rows = appState[tab] || [];
      const q = rows.map(x => {
        if (x.type === "local") return { ...x, type: "local" };
        if (x.type === "local-video") return { ...x, type: "local-video" };
        if (x.type === "radio") return { ...x, type: "radio" };
        if (x.type === "yt" || x.type === "youtube") return { ...x, type: "yt" };
        return { ...x, type: x.type || "radio" };
      });
      setQueue(q, q.length ? 0 : -1);
    }
  }

  renderMediaTab(name, body, opts = {}) {
    const rows = this.mediaData?.[name === "radio" ? "radio" : "youtube"] || [];
    if (opts.syncQueue) this.fillQueueFromTab(name);
    if (name === "yt") return this.renderYoutubeTab(body, rows, opts);
    const bulk = this.manageMode;
    body.innerHTML = `<div class="lib-tab-head"><span>Radio</span></div><div class="media-list">${rows.length ? rows.map((x, i) => {
      const key = this.keyFor(x,i); const sel = this.selected.has(key);
      const img = `<img class="list-icon" src="${x.image || ""}" alt="">`;
      const copy = `<span class="saved-copy"><strong>${(x.title||"").replace(/</g,"&lt;")}</strong><small>${(x.desc||"").replace(/</g,"&lt;")}</small></span>`;
      if (bulk) return `<button class="media-row selectable ${sel?"is-selected":""}" data-select="${i}"><span class="sel-mark">${sel?"☑":"☐"}</span>${img}${copy}</button>`;
      return `<div class="media-row">${img}<button class="media-main" data-play="${i}"><strong>${(x.title||"").replace(/</g,"&lt;")}</strong><small>${(x.desc||"").replace(/</g,"&lt;")}</small></button><button class="fav-toggle" data-fav="${i}" title="Favorit">${appState.favorites.some(f => f.title === x.title) ? "★" : "☆"}</button><button class="row-del" data-del="${i}" title="Hapus">🗑</button></div>`;
    }).join("") : "<p class=panel-hint>Belum ada data. Tambah dengan tombol + Tambah.</p>"}</div>`;
    this.renderToolbar(rows.length);
    if (bulk) {
      body.querySelectorAll("[data-select]").forEach(b => b.onclick = () => {
        const i = +b.dataset.select;
        const key = this.keyFor(rows[i], i);
        this.toggleSelect(key);
        b.classList.toggle("is-selected", this.selected.has(key));
        const mark = b.querySelector(".sel-mark");
        if (mark) mark.textContent = this.selected.has(key) ? "☑" : "☐";
      });
    } else {
      body.querySelectorAll("[data-play]").forEach(b => b.onclick = () => {
        body.querySelectorAll("[data-play]").forEach(x => x.classList.remove("is-active"));
        b.classList.add("is-active");
        setQueue(rows.map(x => ({ ...x, type: name })), +b.dataset.play);
        this.root.dispatchEvent(new CustomEvent("play-queue-index", { detail: { index: +b.dataset.play } }));
      });
      body.querySelectorAll("[data-fav]").forEach(b => b.onclick = async () => {
        const i = +b.dataset.fav;
        await toggleFavorite({ ...rows[i], type: name });
        b.textContent = appState.favorites.some(f => f.title === rows[i].title) ? "★" : "☆";
      });
      body.querySelectorAll("[data-del]").forEach(b => b.onclick = async (e) => { e.stopPropagation(); await this.deleteOne(name, +b.dataset.del); });
    }
  }

  renderYoutubeTab(body, rows, opts = {}) {
    const bulk = this.manageMode;
    const q = (this.ytSearchQuery || "").replace(/"/g, "&quot;");
    const results = this.ytSearchResults;
    let resultsHtml = "";
    if (this.ytSearching) {
      resultsHtml = `<p class="panel-hint">Mencari di YouTube...</p>`;
    } else if (this.ytSearchError) {
      resultsHtml = `<p class="panel-hint">${String(this.ytSearchError).replace(/</g, "&lt;")}</p>`;
    } else if (Array.isArray(results)) {
      resultsHtml = results.length ? `<div class="media-list">${results.map((x, i) => {
        const img = `<img class="list-icon" src="${(x.image||"").replace(/"/g,"&quot;")}" alt="">`;
        const copy = `<span class="saved-copy"><strong>${(x.title||"").replace(/</g,"&lt;")}</strong><small>${(x.desc||"YouTube").replace(/</g,"&lt;")}</small></span>`;
        return `<div class="media-row">${img}<button class="media-main" data-ytres-play="${i}">${copy}</button><button class="fav-toggle" data-ytres-add="${i}" title="Tambah ke Daftar Putar">＋</button></div>`;
      }).join("")}</div>` : `<p class="panel-hint">Tidak ada hasil. Coba kata kunci lain atau periksa koneksi internet.</p>`;
    }

    body.innerHTML = `
      <div class="yt-search-block">
        <div class="lib-tab-head"><span>Cari YouTube (online)</span></div>
        <div class="yt-search-row"><input class="url-input yt-search-input" data-yt-search placeholder="Cari video/lagu di YouTube..." value="${q}"><button class="primary yt-search-btn" type="button" data-yt-search-go>Cari</button></div>
        <div class="yt-search-results" data-yt-results>${resultsHtml}</div>
      </div>
      <div class="lib-tab-head"><span>Playlist Tersimpan</span></div>
      <div class="media-list">${rows.length ? rows.map((x, i) => {
        const key = this.keyFor(x,i); const sel = this.selected.has(key);
        const img = `<img class="list-icon" src="${x.image || ""}" alt="">`;
        const copy = `<span class="saved-copy"><strong>${(x.title||"").replace(/</g,"&lt;")}</strong><small>${(x.desc||"").replace(/</g,"&lt;")}</small></span>`;
        if (bulk) return `<button class="media-row selectable ${sel?"is-selected":""}" data-select="${i}"><span class="sel-mark">${sel?"☑":"☐"}</span>${img}${copy}</button>`;
        return `<div class="media-row">${img}<button class="media-main" data-play="${i}"><strong>${(x.title||"").replace(/</g,"&lt;")}</strong><small>${(x.desc||"").replace(/</g,"&lt;")}</small></button><button class="fav-toggle" data-fav="${i}" title="Favorit">${appState.favorites.some(f => f.title === x.title) ? "★" : "☆"}</button><button class="row-del" data-del="${i}" title="Hapus">🗑</button></div>`;
      }).join("") : "<p class=panel-hint>Belum ada playlist tersimpan. Tambah dengan tombol + Tambah.</p>"}</div>`;

    this.renderToolbar(rows.length);

    // online search handlers
    const doSearch = async () => {
      const input = body.querySelector("[data-yt-search]");
      const query = (input?.value || "").trim();
      this.ytSearchQuery = query;
      this.ytSearchError = "";
      this.ytSearchResults = null;
      if (!query) { await this.renderTab("yt"); return; }
      this.ytSearching = true;
      await this.renderTab("yt");
      try {
        this.ytSearchResults = await searchYouTube(query, { limit: 20 });
        this.ytSearchError = "";
      } catch (e) {
        this.ytSearchResults = [];
        this.ytSearchError = e?.message || "Pencarian gagal. Coba lagi.";
      } finally {
        this.ytSearching = false;
        await this.renderTab("yt");
      }
    };
    body.querySelector("[data-yt-search-go]")?.addEventListener("click", () => { doSearch(); });
    body.querySelector("[data-yt-search]")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); doSearch(); }
    });
    body.querySelectorAll("[data-ytres-play]").forEach(b => b.onclick = () => {
      const i = +b.dataset.ytresPlay;
      const item = (this.ytSearchResults || [])[i];
      if (!item) return;
      setQueue([item], 0);
      this.root.dispatchEvent(new CustomEvent("play-queue-index", { detail: { index: 0 } }));
    });
    body.querySelectorAll("[data-ytres-add]").forEach(b => b.onclick = () => {
      const i = +b.dataset.ytresAdd;
      const item = (this.ytSearchResults || [])[i];
      if (!item) return;
      addToQueue(item);
      b.textContent = "✓";
      setTimeout(() => { try { b.textContent = "＋"; } catch {} }, 1200);
    });

    // saved playlists handlers
    if (bulk) {
      body.querySelectorAll("[data-select]").forEach(b => b.onclick = () => {
        const i = +b.dataset.select;
        const key = this.keyFor(rows[i], i);
        this.toggleSelect(key);
        b.classList.toggle("is-selected", this.selected.has(key));
        const mark = b.querySelector(".sel-mark");
        if (mark) mark.textContent = this.selected.has(key) ? "☑" : "☐";
      });
    } else {
      body.querySelectorAll("[data-play]").forEach(b => b.onclick = () => {
        body.querySelectorAll("[data-play]").forEach(x => x.classList.remove("is-active"));
        b.classList.add("is-active");
        setQueue(rows.map(x => ({ ...x, type: "yt" })), +b.dataset.play);
        this.root.dispatchEvent(new CustomEvent("play-queue-index", { detail: { index: +b.dataset.play } }));
      });
      body.querySelectorAll("[data-fav]").forEach(b => b.onclick = async () => {
        const i = +b.dataset.fav;
        await toggleFavorite({ ...rows[i], type: "yt" });
        b.textContent = appState.favorites.some(f => f.title === rows[i].title) ? "★" : "☆";
      });
      body.querySelectorAll("[data-del]").forEach(b => b.onclick = async (e) => { e.stopPropagation(); await this.deleteOne("yt", +b.dataset.del); });
    }
  }

  renderMp3Tab(body, opts = {}) {
    const playlists = appState.playlists || [];
    const bulk = this.manageMode;
    body.innerHTML = `<div class="lib-tab-head"><span>Playlist Tersimpan</span></div><div class="media-list">${playlists.length ? playlists.map((pl, i) => {
      const key = this.keyFor(pl,i); const sel = this.selected.has(key);
      const inner = `<span class="list-icon" aria-hidden="true">🎵</span><span class="saved-copy"><strong>${(pl.name || "Playlist").replace(/</g, "&lt;")}</strong><small>${Array.isArray(pl.items) ? pl.items.length : 0} lagu</small></span>`;
      if (bulk) return `<button class="media-row saved-row selectable ${sel?"is-selected":""}" data-select="${i}"><span class="sel-mark">${sel?"☑":"☐"}</span>${inner}</button>`;
      return `<div class="media-row saved-row"><button class="media-main" data-pl="${i}">${inner}</button><button class="row-del" data-del="${i}" title="Hapus">🗑</button></div>`;
    }).join("") : "<p class=panel-hint>Belum ada playlist tersimpan. Simpan dari Daftar Putar.</p>"}</div>`;
    this.renderToolbar(playlists.length);
    if (bulk) {
      body.querySelectorAll("[data-select]").forEach(b => b.onclick = () => {
        const i = +b.dataset.select;
        const key = this.keyFor(playlists[i], i);
        this.toggleSelect(key);
        b.classList.toggle("is-selected", this.selected.has(key));
        const mark = b.querySelector(".sel-mark");
        if (mark) mark.textContent = this.selected.has(key) ? "☑" : "☐";
      });
    } else {
      body.querySelectorAll("[data-pl]").forEach(b => b.onclick = () => {
        const pl = playlists[+b.dataset.pl];
        if (!pl) return;
        const label = pl.name || "Playlist";
        const items = Array.isArray(pl.items) ? pl.items.map(x => ({ ...x, queueLabel: label })) : [];
        setQueue(items, items.length ? 0 : -1);
        if (items.length) this.root.dispatchEvent(new CustomEvent("play-queue-index", { detail: { index: 0 } }));
      });
      body.querySelectorAll("[data-del]").forEach(b => b.onclick = async (e) => { e.stopPropagation(); await this.deleteOne("mp3", +b.dataset.del); });
    }
  }

  async renderVideoTab(body, opts = {}) {
    const videos = await storage.get("local-videos", []);
    const rows = Array.isArray(videos) ? videos : [];
    const toQueue = () => rows.map((v, i) => ({
      ...v,
      id: v.id || `video:${v.name || "video"}:${v.size || i}`,
      name: v.name || v.title || "Video",
      title: v.title || v.name || "Video",
      type: "local-video"
    }));
    if (opts.syncQueue) setQueue(toQueue(), rows.length ? 0 : -1);
    const bulk = this.manageMode;
    body.innerHTML = `<div class="lib-tab-head"><span>Video Lokal</span></div><div class="media-list">${rows.length ? rows.map((v, i) => {
      const key = this.keyFor(v,i); const sel = this.selected.has(key);
      const inner = `<span class="list-icon" aria-hidden="true">🎬</span><span class="saved-copy"><strong>${(v.title || v.name || "Video").replace(/</g, "&lt;")}</strong><small>${(v.desc || "Video lokal").replace(/</g, "&lt;")}</small></span>`;
      if (bulk) return `<button class="media-row saved-row selectable ${sel?"is-selected":""}" data-select="${i}"><span class="sel-mark">${sel?"☑":"☐"}</span>${inner}</button>`;
      return `<div class="media-row saved-row"><button class="media-main" data-play="${i}">${inner}</button><button class="row-del" data-del="${i}" title="Hapus">🗑</button></div>`;
    }).join("") : "<p class=panel-hint>Belum ada video. Tambah video lokal dengan tombol + Tambah.</p>"}</div>`;
    this.renderToolbar(rows.length);
    if (bulk) {
      body.querySelectorAll("[data-select]").forEach(b => b.onclick = () => {
        const i = +b.dataset.select;
        const key = this.keyFor(rows[i], i);
        this.toggleSelect(key);
        b.classList.toggle("is-selected", this.selected.has(key));
        const mark = b.querySelector(".sel-mark");
        if (mark) mark.textContent = this.selected.has(key) ? "☑" : "☐";
      });
    } else {
      body.querySelectorAll("[data-play]").forEach(b => b.onclick = () => {
        const idx = +b.dataset.play;
        const q = toQueue();
        setQueue(q, idx);
        this.root.dispatchEvent(new CustomEvent("play-queue-index", { detail: { index: idx } }));
      });
      body.querySelectorAll("[data-del]").forEach(b => b.onclick = async (e) => { e.stopPropagation(); await this.deleteOne("video", +b.dataset.del); });
    }
  }

  renderSavedTab(name, body, opts = {}) {
    const rows = appState[name] || [];
    const label = name === "favorites" ? "Favorit" : "Recent";
    if (opts.syncQueue) this.fillQueueFromTab(name);
    const bulk = this.manageMode;
    body.innerHTML = `<div class="lib-tab-head"><span>${label}</span></div><div class="media-list">${rows.length ? rows.map((x, i) => {
      const key = this.keyFor(x,i); const sel = this.selected.has(key);
      const inner = `<img class="list-icon" src="${x.image || "./src/assets/ria-music.svg"}" alt=""><span class="saved-copy"><strong>${(x.title||"").replace(/</g,"&lt;")}</strong><small>${(x.desc || "Local music").replace(/</g,"&lt;")}</small></span>`;
      if (bulk) return `<button class="media-row saved-row selectable ${sel?"is-selected":""}" data-select="${i}"><span class="sel-mark">${sel?"☑":"☐"}</span>${inner}</button>`;
      return `<div class="media-row saved-row"><button class="media-main" data-play="${i}">${inner}</button><button class="row-del" data-del="${i}" title="Hapus">🗑</button></div>`;
    }).join("") : "<p class=panel-hint>Belum ada data.</p>"}</div>`;
    this.renderToolbar(rows.length);
    if (bulk) {
      body.querySelectorAll("[data-select]").forEach(b => b.onclick = () => {
        const i = +b.dataset.select;
        const key = this.keyFor(rows[i], i);
        this.toggleSelect(key);
        b.classList.toggle("is-selected", this.selected.has(key));
        const mark = b.querySelector(".sel-mark");
        if (mark) mark.textContent = this.selected.has(key) ? "☑" : "☐";
      });
    } else {
      body.querySelectorAll("[data-play]").forEach(b => b.onclick = () => {
        body.querySelectorAll("[data-play]").forEach(x => x.classList.remove("is-active"));
        b.classList.add("is-active");
        setQueue((appState[name] || []).map(x => {
          if (x.type === "local") return { ...x, type: "local" };
          if (x.type === "local-video") return { ...x, type: "local-video" };
          if (x.type === "radio") return { ...x, type: "radio" };
          if (x.type === "yt" || x.type === "youtube") return { ...x, type: "yt" };
          return { ...x, type: x.type || "radio" };
        }), +b.dataset.play);
        this.root.dispatchEvent(new CustomEvent("play-queue-index", { detail: { index: +b.dataset.play } }));
      });
      body.querySelectorAll("[data-del]").forEach(b => b.onclick = async (e) => { e.stopPropagation(); await this.deleteOne(name, +b.dataset.del); });
    }
  }
}















