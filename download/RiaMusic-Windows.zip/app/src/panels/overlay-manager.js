import { preferences } from "../preferences.js";

const views = { about: ["About", "Informasi aplikasi RiaMusic"] };

function renderPanelView(name) {
  const [title] = views[name] || ["Panel", ""];
  const icon = name === "about" ? "ⓘ" : "•";
  const logo = new URL("../assets/ria-music.svg", import.meta.url).href;
  const content = `<img class="about-logo" src="${logo}" alt="RiaMusic logo"><div class="about-copy"><p>RiaMusic</p><p>After The Silent</p><p>+6282338013610</p><p>riacaya99@gmail.com</p><p>Versi 1.0.0</p></div>`;
  return `<div class="panel-shell about-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">${icon}</span>${title}</h2><span></span></header><div class="body-card">${content}</div></div>`;
}

function renderGuideView() {
  const content = `
    <section class="guide-section"><h3>Tambah &amp; Putar</h3><ul>
      <li><b>+ Tambah:</b> pilih file audio/video lokal dari perangkat.</li>
      <li><b>URL:</b> putar tautan audio atau video (stream).</li>
      <li><b>Playlist:</b> buka tab YT, Radio, MP3 (playlist tersimpan), Video, Favorit, atau Recent lalu pilih item untuk diputar.</li>
    </ul></section>
    <section class="guide-section"><h3>Daftar Putar</h3><ul>
      <li>Lihat antrian lagu yang aktif, cari, lompat ke item, <b>Kosongkan</b>, atau <b>Simpan</b> sebagai playlist.</li>
    </ul></section>
    <section class="guide-section"><h3>Playlist &amp; Koleksi</h3><ul>
      <li>Kelola daftar YT/Radio/Video, simpan daftar putar ke tab <b>MP3</b>, tandai <b>Favorit</b>, dan akses <b>Recent</b> (riwayat putar).</li>
      <li>Gunakan mode <b>Pilih</b>/hapus untuk mengelola item.</li>
    </ul></section>
    <section class="guide-section"><h3>Kontrol &amp; Lainnya</h3><ul>
      <li>Play/Pause, Next/Prev, Shuffle/Repeat, volume/mute, dan <b>Record Radio</b> saat memutar radio.</li>
      <li><b>Settings:</b> tema, bahasa, volume, equalizer, dan timer tidur.</li>
      <li><b>Auto-play:</b> saat aplikasi dibuka, daftar putar dimuat dari Recent (instalasi pertama boleh kosong).</li>
    </ul></section>`;
  return `<div class="panel-shell guide-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">📖</span>Panduan</h2><span></span></header><div class="body-card guide-body">${content}</div></div>`;
}

function formatTime(ms) {
  const total = Math.max(0, Math.floor((ms || 0) / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = n => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}
function formatDate(ts) {
  try { const d = new Date(ts); return d.toLocaleString(); } catch { return ""; }
}

export class OverlayManager {
  constructor(root) { this.root = root; this._cleanup = null; this._selectedRecId = null; }
  close() {
    try { if (typeof this._cleanup === "function") this._cleanup(); } catch {}
    this._cleanup = null;
    this.root.classList.remove("show");
    this.root.replaceChildren();
  }
  bind() { this.root.querySelector("[data-close]")?.addEventListener("click", () => this.close()); }

  open(name) {
    try { if (typeof this._cleanup === "function") this._cleanup(); } catch {}
    this._cleanup = null;
    this.root.classList.add("show");
    if (name === "menu") return this.menu();
    if (name === "settings") return this.settings();
    if (name === "url") return this.url();
    if (name === "guide") { this.root.innerHTML = renderGuideView(); this.bind(); return; }
    if (name === "record") return this.record();
    this.root.innerHTML = renderPanelView(name);
    this.bind();
  }

  menu() {
    const isApk = typeof document !== "undefined" && document.body?.classList.contains("is-apk");
    const items = [
      ["＋","action","add-local","Tambah File","Muat file lokal ke daftar putar"],
      ...(isApk ? [["📄","queue","queue","Daftar Putar","Buka daftar putar"]] : []),
      ["♫","library","mp3","Playlist","Buka playlist lagu lokal"],
      ["⚙","overlay","settings","Settings","Tema, bahasa, volume, dan equalizer"],
      ["●","overlay","record","Record Radio","Rekam siaran radio"],
      ["🔗","overlay","url","URL","Putar link audio atau video"],
      ["📖","overlay","guide","Panduan","Panduan penggunaan RiaMusic"],
      ["ⓘ","overlay","about","About","Informasi aplikasi RiaMusic"],
    ];
    this.root.innerHTML = `<div class="panel-shell menu-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">☰</span>Menu</h2><span></span></header><div class="panel-menu">${items.map(([icon, kind, target, title, desc]) => `<button data-menu-kind="${kind}" data-menu-target="${target}"><span class="menu-icon">${icon}</span><span class="menu-copy"><strong>${title}</strong><small>${desc}</small></span></button>`).join("")}</div></div>`;
    this.bind();
    this.root.querySelectorAll("[data-menu-kind]").forEach(btn => btn.addEventListener("click", () => {
      const kind = btn.dataset.menuKind, target = btn.dataset.menuTarget;
      this.close();
      if (kind === "queue") this.root.dispatchEvent(new CustomEvent("open-queue"));
      else if (kind === "action" && target === "add-local") this.root.dispatchEvent(new CustomEvent("add-local"));
      else if (kind === "library") this.root.dispatchEvent(new CustomEvent("open-library", { detail: target }));
      else this.root.dispatchEvent(new CustomEvent("open-overlay", { detail: target }));
    }));
  }

  record() {
    const rec = (typeof window !== "undefined" && window.__riaRadioRecorder) ? window.__riaRadioRecorder : null;
    const autoOptions = [
      ["0", "Mati"],
      ["180000", "3 menit"],
      ["300000", "5 menit"],
      ["600000", "10 menit"],
      ["900000", "15 menit"],
      ["1800000", "30 menit"],
      ["3600000", "1 jam"],
    ];
    const st0 = rec ? rec.getState() : { recording: false, elapsedMs: 0, station: "", autoStopMs: 0, recordings: [] };
    const autoVal = String(st0.autoStopMs || 0);
    this.root.innerHTML = `<div class="panel-shell record-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">●</span>Record Radio</h2><span></span></header><div class="body-card record-body">
      <div class="record-status">
        <div class="record-timer" data-rec-timer>${st0.recording ? formatTime(st0.elapsedMs) : "0:00"}</div>
        <div class="record-state" data-rec-state>${st0.recording ? "Merekam" : "Siap merekam"}</div>
        <div class="record-station" data-rec-station>${(st0.station || (document.querySelector("#player-stage")?.dataset.mode === "radio" ? (document.querySelector("#title")?.textContent || "") : "") || "").replace(/</g,"&lt;")}</div>
        <div class="record-hint" data-rec-hint>${st0.recording ? "Perekaman sedang berjalan..." : "Putar radio, lalu tekan Mulai untuk merekam."}</div>
      </div>
      <div class="record-autostop"><label for="rec-autostop">Auto stop</label><select id="rec-autostop" class="setting-select" data-rec-autostop>${autoOptions.map(([v,l]) => `<option value="${v}" ${v===autoVal?"selected":""}>${l}</option>`).join("")}</select></div>
      <div class="record-controls">
        <button type="button" class="primary" data-rec-start>Mulai</button>
        <button type="button" data-rec-stop>Stop</button>
        <button type="button" data-rec-play>Putar</button>
      </div>
      <audio data-rec-audio preload="metadata" controls class="record-audio"></audio>
      <div class="record-list-wrap"><div class="record-list-head"><span>Hasil Rekaman</span><button type="button" class="record-clear" data-rec-clear>Hapus semua</button></div><div class="record-list" data-rec-list></div></div>
    </div></div>`;
    this.bind();

    const audioEl = this.root.querySelector("[data-rec-audio]");
    const listEl = this.root.querySelector("[data-rec-list]");
    const timerEl = this.root.querySelector("[data-rec-timer]");
    const stateEl = this.root.querySelector("[data-rec-state]");
    const stationEl = this.root.querySelector("[data-rec-station]");
    const hintEl = this.root.querySelector("[data-rec-hint]");
    const autoSel = this.root.querySelector("[data-rec-autostop]");
    const btnStart = this.root.querySelector("[data-rec-start]");
    const btnStop = this.root.querySelector("[data-rec-stop]");
    const btnPlay = this.root.querySelector("[data-rec-play]");

    const getRec = () => (typeof window !== "undefined" && window.__riaRadioRecorder) ? window.__riaRadioRecorder : null;
    const getSelected = () => {
      const r = getRec(); if (!r) return null;
      const items = r.getState().recordings || [];
      let sel = items.find(x => x.id === this._selectedRecId);
      if (!sel && items.length) sel = items[0];
      this._selectedRecId = sel ? sel.id : null;
      return sel;
    };

    const renderList = () => {
      const r = getRec(); if (!r || !listEl) return;
      const items = r.getState().recordings || [];
      if (!items.length) { listEl.innerHTML = `<p class="panel-hint">Belum ada rekaman.</p>`; return; }
      if (!this._selectedRecId || !items.some(x => x.id === this._selectedRecId)) this._selectedRecId = items[0].id;
      listEl.innerHTML = items.map(item => {
        const sel = item.id === this._selectedRecId ? " is-selected" : "";
        const dur = item.durationMs ? formatTime(item.durationMs) : "";
        const meta = [dur, formatDate(item.createdAt)].filter(Boolean).join(" • ");
        const status = item.ok ? "" : (item.blobUrl ? " (sementara)" : " (gagal disimpan)");
        const title = (item.title || item.name || "Rekaman").replace(/</g,"&lt;");
        return `<button type="button" class="record-item${sel}" data-rec-id="${item.id}"><span class="rec-copy"><strong>${title}</strong><small>${meta.replace(/</g,"&lt;")}${status}</small></span><span class="rec-del" data-rec-del="${item.id}" title="Hapus">×</span></button>`;
      }).join("");
      listEl.querySelectorAll("[data-rec-id]").forEach(btn => btn.addEventListener("click", (e) => {
        if (e.target.closest("[data-rec-del]")) return;
        this._selectedRecId = btn.getAttribute("data-rec-id");
        renderList();
      }));
      listEl.querySelectorAll("[data-rec-del]").forEach(btn => btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const id = btn.getAttribute("data-rec-del");
        const r2 = getRec(); if (!r2) return;
        const ok = (typeof confirm === "function") ? confirm("Hapus rekaman ini dari daftar?") : true;
        if (!ok) return;
        await r2.removeRecording(id);
        renderList();
      }));
    };

    const renderState = (state) => {
      const r = getRec(); const st = state || (r ? r.getState() : null);
      if (!st) { if (hintEl) hintEl.textContent = "Fitur rekam belum siap."; return; }
      if (timerEl) timerEl.textContent = st.recording ? formatTime(st.elapsedMs) : (timerEl.textContent === "0:00" || st.elapsedMs === 0 ? "0:00" : timerEl.textContent);
      if (stateEl) stateEl.textContent = st.recording ? "Merekam" : "Siap merekam";
      const stationNow = st.station || (document.querySelector("#player-stage")?.dataset.mode === "radio" ? (document.querySelector("#title")?.textContent || "") : "");
      if (stationEl) stationEl.textContent = stationNow || "—";
      if (hintEl) hintEl.textContent = st.recording ? "Perekaman sedang berjalan..." : "Putar radio, lalu tekan Mulai untuk merekam.";
      if (btnStart) btnStart.disabled = !!st.recording || !st.supported;
      if (btnStop) btnStop.disabled = !st.recording;
      if (autoSel && document.activeElement !== autoSel) autoSel.value = String(st.autoStopMs || 0);
      // refresh list on state updates (e.g. new recording saved)
      renderList();
    };

    if (rec) { rec.loadRecordings().then(() => { renderList(); renderState(); }); }
    else { renderList(); renderState(null); }

    autoSel?.addEventListener("change", () => { const r = getRec(); if (r) r.setAutoStopMs(Number(autoSel.value || 0)); });

    btnStart?.addEventListener("click", async () => {
      const r = getRec(); if (!r) { if (hintEl) hintEl.textContent = "Fitur rekam belum siap."; return; }
      if (document.querySelector("#player-stage")?.dataset.mode !== "radio") { if (hintEl) hintEl.textContent = "Putar stasiun radio terlebih dahulu."; return; }
      // ensure analyser prepared (same as main flow)
      try { const streamEl = document.querySelector("#streamAudio"); r.prepare(streamEl, [...document.querySelectorAll("#eq span")]); r.resume(); } catch {}
      const stationName = (document.querySelector("#title")?.textContent || "").trim();
      const res = await r.start(stationName);
      if (res && res.ok === false && hintEl) hintEl.textContent = res.error || "Perekaman tidak dapat dimulai.";
      renderState();
    });
    btnStop?.addEventListener("click", () => { const r = getRec(); if (r) r.stop(); renderState(); });
    btnPlay?.addEventListener("click", () => {
      const r = getRec(); const sel = getSelected();
      if (!r || !sel || !audioEl) { if (hintEl) hintEl.textContent = "Pilih rekaman untuk diputar."; return; }
      const src = r.getPlayableSrc(sel);
      if (!src) { if (hintEl) hintEl.textContent = "Rekaman tidak dapat diputar (file tidak tersedia)."; return; }
      try { audioEl.pause(); } catch {}
      audioEl.src = src;
      audioEl.play().catch(() => { if (hintEl) hintEl.textContent = "Tidak dapat memutar rekaman ini."; });
    });

    this.root.querySelector("[data-rec-clear]")?.addEventListener("click", async () => {
      const r = getRec(); if (!r) return;
      const ok = (typeof confirm === "function") ? confirm("Hapus semua rekaman dari daftar?") : true;
      if (!ok) return;
      await r.clearRecordings();
      this._selectedRecId = null;
      renderList();
    });

    // live updates while panel open
    if (rec) {
      const unsub = rec.subscribe((st) => renderState(st));
      this._cleanup = () => { try { unsub(); } catch {} try { audioEl?.pause(); } catch {} };
    } else {
      this._cleanup = () => { try { audioEl?.pause(); } catch {} };
    }
  }

  settings() {
    const themes = ["mystic", "dusk", "midnight", "sunrise"], eq = ["flat", "pop", "rock", "jazz", "classical"];
    const current = preferences.get();
    this.root.innerHTML = `<div class="panel-shell settings-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">⚙</span>Settings</h2><span></span></header><div class="settings-cards">
      <section><b>Bahasa <em>${(current.language || "en").toUpperCase()}</em></b><select class="setting-select" data-language-select><option value="en">EN</option><option value="id">ID</option></select></section>
      <section><b>Theme <em>${current.theme}</em></b><div class="choice vertical">${themes.map(x => `<button data-theme="${x}"><span class="theme-icon theme-${x}">${({ mystic: "🌙", dusk: "🌆", midnight: "🌌", sunrise: "🌅" })[x]}</span>${x}</button>`).join("")}</div></section>
      <section><b>Equalizer <em>${current.equalizer}</em></b><select class="setting-select" data-equalizer-select>${eq.map(x => `<option value="${x}">${x}</option>`).join("")}</select><p>Radio, MP3, URL audio</p></section>
      <section><b>Sleep Timer <em>${current.sleep}</em></b><select class="setting-select" data-sleep-select><option>Off</option><option>15 min</option><option>30 min</option><option>60 min</option></select></section>
      <section><b>Volume <em>${current.volume}%</em></b><input class="setting-range" type="range" min="0" max="100" value="${current.volume}"></section>
      <section><b>Cache &amp; Data</b><button type="button" class="setting-action danger" data-clear-cache>Bersihkan Cache</button><p>Hapus cache, data lokal (playlist, favorit, riwayat, pengaturan, daftar putar), lalu muat ulang aplikasi.</p></section>
    </div></div>`;
    this.bind();
    this.root.querySelector("[data-language-select]").value = current.language || "en";
    this.root.querySelector("[data-language-select]").onchange = e => { preferences.set("language", e.target.value); this.settings(); };
    this.root.querySelectorAll("[data-theme]").forEach(b => b.onclick = () => { document.documentElement.dataset.theme = b.dataset.theme; preferences.set("theme", b.dataset.theme); this.settings(); });
    this.root.querySelector("[data-equalizer-select]").value = current.equalizer;
    this.root.querySelector("[data-equalizer-select]").onchange = e => preferences.set("equalizer", e.target.value);
    this.root.querySelector("[data-sleep-select]").value = current.sleep;
    this.root.querySelector("[data-sleep-select]").onchange = e => preferences.set("sleep", e.target.value);
    this.root.querySelector(".setting-range").value = current.volume;
    this.root.querySelector(".setting-range").oninput = e => { document.querySelector("#volume").value = e.target.value; preferences.set("volume", Number(e.target.value)); document.querySelector("#volume").dispatchEvent(new Event("input", { bubbles: true })); };
    this.root.querySelector("[data-clear-cache]")?.addEventListener("click", async () => {
      if (typeof confirm === "function" && !confirm("Bersihkan cache dan data lokal aplikasi?\n\nPlaylist, favorit, riwayat, pengaturan, daftar putar, dan data rekaman akan dihapus, lalu aplikasi dimuat ulang.")) return;
      try {
        try { if (typeof caches !== "undefined" && caches.keys) { const keys = await caches.keys(); await Promise.all(keys.map(k => caches.delete(k))); } } catch {}
        try { if (navigator.serviceWorker?.getRegistrations) { const regs = await navigator.serviceWorker.getRegistrations(); await Promise.all(regs.map(r => r.unregister())); } } catch {}
        try { localStorage.clear(); } catch {}
        try { sessionStorage.clear(); } catch {}
        try {
          if (typeof indexedDB !== "undefined") {
            if (indexedDB.databases) {
              const dbs = await indexedDB.databases();
              await Promise.all((dbs || []).map(db => db?.name ? new Promise(res => { const req = indexedDB.deleteDatabase(db.name); req.onsuccess = req.onerror = req.onblocked = () => res(); }) : Promise.resolve()));
            } else {
              await new Promise(res => { const req = indexedDB.deleteDatabase("riaMusicLibrary"); req.onsuccess = req.onerror = req.onblocked = () => res(); });
            }
          }
        } catch {}
        try {
          const b = (typeof window !== "undefined" && window.RiaBridge) ? window.RiaBridge : null;
          if (b?.userDataDelete) {
            const targets = ["Favorite.json", "recent.json", "mp3-played.json", "recordings.json", "playlist"];
            for (const t of targets) { try { await b.userDataDelete(t); } catch {} }
          }
          if (b?.clearAppCache) await b.clearAppCache(); else if (b?.clearCache) await b.clearCache();
        } catch {}
      } finally {
        try { const url = new URL(location.href); url.searchParams.set("_r", Date.now().toString()); location.replace(url.toString()); } catch { location.reload(); }
      }
    });
  }

  url() {
    this.root.innerHTML = `<div class="panel-shell url-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">🔗</span>URL</h2><span></span></header><div class="body-card"><input class="url-input" data-url placeholder="https://.../stream.mp3"><button class="primary url-button" data-play-url>Putar URL</button></div></div>`;
    this.bind();
    this.root.querySelector("[data-play-url]").onclick = () => {
      const u = this.root.querySelector("[data-url]").value.trim();
      if (u.startsWith("http://") || u.startsWith("https://")) this.root.dispatchEvent(new CustomEvent("play-url", { detail: u }));
    };
  }
}
