import { preferences } from "../preferences.js";

const views = { about: ["About", "Informasi aplikasi RiaMusic"] };

function renderPanelView(name) {
  const [title] = views[name] || ["Panel", ""];
  const icon = name === "about" ? "ⓘ" : "•";
  const logo = new URL("../assets/ria-music.svg", import.meta.url).href;
  const content = `<img class="about-logo" src="${logo}" alt="RiaMusic logo"><div class="about-copy"><p>RiaMusic</p><p>After The Silent</p><p>+6282338013610</p><p>riacaya99@gmail.com</p><p>Versi 1.0.0</p></div>`;
  return `<div class="panel-shell about-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">${icon}</span>${title}</h2><span></span></header><div class="body-card">${content}</div></div>`;
}

function renderGuideView() {
  const content = `
    <section class="guide-section"><h3>Tambah &amp; Putar</h3><ul>
      <li><b>+ Tambah:</b> pilih file audio/video lokal dari perangkat.</li>
      <li><b>URL:</b> putar tautan audio atau video (stream).</li>
      <li><b>Playlist:</b> buka tab YT, Radio, MP3 (playlist tersimpan), Video, Favorit, atau Recent lalu pilih item untuk diputar.</li>
    </ul></section>
    <section class="guide-section"><h3>Daftar Putar</h3><ul>
      <li>Lihat antrian lagu yang aktif, cari, lompat ke item, <b>Kosongkan</b>, atau <b>Simpan</b> sebagai playlist.</li>
    </ul></section>
    <section class="guide-section"><h3>Playlist &amp; Koleksi</h3><ul>
      <li>Kelola daftar YT/Radio/Video, simpan daftar putar ke tab <b>MP3</b>, tandai <b>Favorit</b>, dan akses <b>Recent</b> (riwayat putar).</li>
      <li>Gunakan mode <b>Pilih</b>/hapus untuk mengelola item.</li>
    </ul></section>
    <section class="guide-section"><h3>Kontrol &amp; Lainnya</h3><ul>
      <li>Play/Pause, Next/Prev, Shuffle/Repeat, volume/mute, dan <b>Record Radio</b> saat memutar radio.</li>
      <li><b>Settings:</b> tema, bahasa, volume, equalizer, dan timer tidur.</li>
      <li><b>Auto-play:</b> pertama kali dibuka memutar item YT pertama; selanjutnya melanjutkan item/daftar putar terakhir sebelum aplikasi ditutup.</li>
    </ul></section>`;
  return `<div class="panel-shell guide-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">📖</span>Panduan</h2><span></span></header><div class="body-card guide-body">${content}</div></div>`;
}

export class OverlayManager {
  constructor(root) { this.root = root; }
  close() { this.root.classList.remove("show"); this.root.replaceChildren(); }
  bind() { this.root.querySelector("[data-close]")?.addEventListener("click", () => this.close()); }

  open(name) {
    if (name === "record") { this.root.dispatchEvent(new CustomEvent("record-radio")); return; }
    this.root.classList.add("show");
    if (name === "menu") return this.menu();
    if (name === "settings") return this.settings();
    if (name === "url") return this.url();
    if (name === "guide") { this.root.innerHTML = renderGuideView(); this.bind(); return; }
    this.root.innerHTML = renderPanelView(name);
    this.bind();
  }

  menu() {
    const isApk = typeof document !== "undefined" && document.body?.classList.contains("is-apk");
    const items = [
      ["＋","action","add-local","Tambah File","Muat file lokal ke daftar putar"],
      ...(isApk ? [["📄","queue","queue","Daftar Putar","Buka daftar putar"]] : []),
      ["♫","library","mp3","Playlist","Buka playlist lagu lokal"],
      ["⚙","overlay","settings","Settings","Tema, bahasa, volume, dan equalizer"],
      ["●","overlay","record","Record Radio","Rekam siaran radio"],
      ["🔗","overlay","url","URL","Putar link audio atau video"],
      ["📖","overlay","guide","Panduan","Panduan penggunaan RiaMusic"],
      ["ⓘ","overlay","about","About","Informasi aplikasi RiaMusic"],
    ];
    this.root.innerHTML = `<div class="panel-shell menu-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">☰</span>Menu</h2><span></span></header><div class="panel-menu">${items.map(([icon, kind, target, title, desc]) => `<button data-menu-kind="${kind}" data-menu-target="${target}"><span class="menu-icon">${icon}</span><span class="menu-copy"><strong>${title}</strong><small>${desc}</small></span></button>`).join("")}</div></div>`;
    this.bind();
    this.root.querySelectorAll("[data-menu-kind]").forEach(btn => btn.addEventListener("click", () => {
      const kind = btn.dataset.menuKind, target = btn.dataset.menuTarget;
      this.close();
      if (kind === "queue") this.root.dispatchEvent(new CustomEvent("open-queue"));
      else if (kind === "action" && target === "add-local") this.root.dispatchEvent(new CustomEvent("add-local"));
      else if (kind === "library") this.root.dispatchEvent(new CustomEvent("open-library", { detail: target }));
      else this.root.dispatchEvent(new CustomEvent("open-overlay", { detail: target }));
    }));
  }

  settings() {
    const themes = ["mystic", "dusk", "midnight", "sunrise"], eq = ["flat", "pop", "rock", "jazz", "classical"];
    const current = preferences.get();
    this.root.innerHTML = `<div class="panel-shell settings-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">⚙</span>Settings</h2><span></span></header><div class="settings-cards">
      <section><b>Bahasa <em>${(current.language || "en").toUpperCase()}</em></b><select class="setting-select" data-language-select><option value="en">EN</option><option value="id">ID</option></select></section>
      <section><b>Theme <em>${current.theme}</em></b><div class="choice vertical">${themes.map(x => `<button data-theme="${x}"><span class="theme-icon theme-${x}">${({ mystic: "🌙", dusk: "🌆", midnight: "🌌", sunrise: "🌅" })[x]}</span>${x}</button>`).join("")}</div></section>
      <section><b>Equalizer <em>${current.equalizer}</em></b><select class="setting-select" data-equalizer-select>${eq.map(x => `<option value="${x}">${x}</option>`).join("")}</select><p>Radio, MP3, URL audio</p></section>
      <section><b>Sleep Timer <em>${current.sleep}</em></b><select class="setting-select" data-sleep-select><option>Off</option><option>15 min</option><option>30 min</option><option>60 min</option></select></section>
      <section><b>Volume <em>${current.volume}%</em></b><input class="setting-range" type="range" min="0" max="100" value="${current.volume}"></section>
      <section><b>Cache &amp; Data</b><button type="button" class="setting-action danger" data-clear-cache>Bersihkan Cache</button><p>Hapus cache, data lokal (playlist, favorit, riwayat, pengaturan, daftar putar), lalu muat ulang aplikasi.</p></section>
    </div></div>`;
    this.bind();
    this.root.querySelector("[data-language-select]").value = current.language || "en";
    this.root.querySelector("[data-language-select]").onchange = e => { preferences.set("language", e.target.value); this.settings(); };
    this.root.querySelectorAll("[data-theme]").forEach(b => b.onclick = () => { document.documentElement.dataset.theme = b.dataset.theme; preferences.set("theme", b.dataset.theme); this.settings(); });
    this.root.querySelector("[data-equalizer-select]").value = current.equalizer;
    this.root.querySelector("[data-equalizer-select]").onchange = e => preferences.set("equalizer", e.target.value);
    this.root.querySelector("[data-sleep-select]").value = current.sleep;
    this.root.querySelector("[data-sleep-select]").onchange = e => preferences.set("sleep", e.target.value);
    this.root.querySelector(".setting-range").value = current.volume;
    this.root.querySelector(".setting-range").oninput = e => { document.querySelector("#volume").value = e.target.value; preferences.set("volume", Number(e.target.value)); document.querySelector("#volume").dispatchEvent(new Event("input", { bubbles: true })); };
    this.root.querySelector("[data-clear-cache]")?.addEventListener("click", async () => {
      if (typeof confirm === "function" && !confirm("Bersihkan cache dan data lokal aplikasi?\n\nPlaylist, favorit, riwayat, pengaturan, dan daftar putar akan dihapus, lalu aplikasi dimuat ulang.")) return;
      try {
        try { if (typeof caches !== "undefined" && caches.keys) { const keys = await caches.keys(); await Promise.all(keys.map(k => caches.delete(k))); } } catch {}
        try { if (navigator.serviceWorker?.getRegistrations) { const regs = await navigator.serviceWorker.getRegistrations(); await Promise.all(regs.map(r => r.unregister())); } } catch {}
        try { localStorage.clear(); } catch {}
        try { sessionStorage.clear(); } catch {}
        try {
          if (typeof indexedDB !== "undefined") {
            if (indexedDB.databases) {
              const dbs = await indexedDB.databases();
              await Promise.all((dbs || []).map(db => db?.name ? new Promise(res => { const req = indexedDB.deleteDatabase(db.name); req.onsuccess = req.onerror = req.onblocked = () => res(); }) : Promise.resolve()));
            } else {
              await new Promise(res => { const req = indexedDB.deleteDatabase("riaMusicLibrary"); req.onsuccess = req.onerror = req.onblocked = () => res(); });
            }
          }
        } catch {}
        try { const b = (typeof window !== "undefined" && window.RiaBridge) ? window.RiaBridge : null; if (b?.clearAppCache) await b.clearAppCache(); else if (b?.clearCache) await b.clearCache(); } catch {}
      } finally {
        try { const url = new URL(location.href); url.searchParams.set("_r", Date.now().toString()); location.replace(url.toString()); } catch { location.reload(); }
      }
    });
  }

  url() {
    this.root.innerHTML = `<div class="panel-shell url-panel"><header><button data-close>&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">🔗</span>URL</h2><span></span></header><div class="body-card"><input class="url-input" data-url placeholder="https://.../stream.mp3"><button class="primary url-button" data-play-url>Putar URL</button></div></div>`;
    this.bind();
    this.root.querySelector("[data-play-url]").onclick = () => {
      const u = this.root.querySelector("[data-url]").value.trim();
      if (u.startsWith("http://") || u.startsWith("https://")) this.root.dispatchEvent(new CustomEvent("play-url", { detail: u }));
    };
  }
}
