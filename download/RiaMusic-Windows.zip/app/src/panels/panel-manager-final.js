import { renderMp3Panel } from "./mp3-panel-view.js?v=refactor1";
import { localPanel, localLibrary, fileSource, storage } from "../app.js";
import { renderPanelView } from "./panel-views.js?v=refactor4";
import { RADIO, YT } from "../data/media-data.js";
import { appState, toggleFavorite } from "../state.js";
import { renderVideoPanel } from "./video-panel-view.js";
import { preferences } from "../preferences.js";

const FALLBACK_ARTWORK="./src/assets/ria-music.svg";
const videoThumbnail= file => new Promise(resolve=>{
  const video=document.createElement("video");
  const url=URL.createObjectURL(file);
  video.preload="metadata"; video.muted=true; video.src=url;
  video.addEventListener("loadeddata",()=>{video.currentTime=Math.min(.1,video.duration||0);},{once:true});
  video.addEventListener("seeked",()=>{try{const canvas=document.createElement("canvas");canvas.width=320;canvas.height=180;canvas.getContext("2d").drawImage(video,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL("image/jpeg",.78));}catch{resolve(FALLBACK_ARTWORK)}finally{URL.revokeObjectURL(url)}},{once:true});
  video.addEventListener("error",()=>{URL.revokeObjectURL(url);resolve(FALLBACK_ARTWORK)},{once:true});
});

export class PanelManager {
  constructor(root){ this.root=root; }
  close(){ this.root.classList.remove("show"); this.root.replaceChildren(); }
  bind(){ this.root.querySelector("[data-close]")?.addEventListener("click",()=>this.close()); const h=this.root.querySelector(".panel-shell h2"); if(h&&!h.querySelector(".panel-title-icon")){const icons={Menu:"☰",Radio:"📻","YT Playlist":"▶",Video:"▣","Video Lokal":"▣",Favorites:"★",Recent:"↻",MP3:"♫",URL:"∞",Settings:"⚙",About:"ⓘ",Search:"⌕"};const i=document.createElement("span");i.className="panel-title-icon";i.textContent=icons[h.textContent.trim()]||"•";h.prepend(i);}}
  open(name){
    this.root.classList.add("show");
    if(name==="menu")return this.menu(); if(name==="mp3")return this.mp3();
    if(name==="radio"||name==="yt")return this.media(name);
    if(name==="favorites"||name==="recent")return this.saved(name);
    if(name==="record"){this.root.dispatchEvent(new CustomEvent("record-radio"));return;} if(name==="settings")return this.settings(); if(name==="url")return this.url();
    if(name==="video")return this.video(); if(name==="search")return this.search();
    this.root.innerHTML=renderPanelView(name); this.bind();
  }
  menu(){
    const a=[["yt","▶","YT Playlist","YouTube playlist"],["radio","▱","Radio","Selected radio streams"],["mp3","♫","MP3","Music from your device"],["video","▣","Video","Video from URL"],["favorites","★","Favorites","Saved favorite items"],["recent","↻","Recent","Recently played items"],["url","∞","URL","Audio / video from a link"],["record","●","Record Radio","Record the active radio"],["settings","⚙","Settings","Theme, language, volume"],["about","i","About","Contact and version"]];
    this.root.innerHTML=`<div class="panel-shell menu-panel"><header><button data-close>←</button><h2>Menu</h2></header><div class="panel-menu">${a.map(x=>`<button data-panel="${x[0]}"><i>${x[1]}</i><span><strong>${x[2]}</strong><small>${x[3]}</small></span></button>`).join("")}</div></div>`;
    this.bind(); this.root.querySelectorAll("[data-panel]").forEach(b=>b.onclick=()=>this.open(b.dataset.panel));
  }
  mp3(){
    this.root.innerHTML = renderMp3Panel();
    this.bind();
    localPanel({
      addFolder: this.root.querySelector("[data-add-folder]"),
      railPlaylist: this.root.querySelector("[data-rail-playlist]"),
      tabs: [...this.root.querySelectorAll("[data-tab]")],
      panes: [...this.root.querySelectorAll("[data-pane]")],
      list: this.root.querySelector("[data-list]"),
      playedList: this.root.querySelector("[data-played-list]"),
      clearPlayed: this.root.querySelector("[data-clear-played]"),
      savePlayed: this.root.querySelector("[data-save-played]"),
      playlistCards: this.root.querySelector("[data-playlist-cards]")
    }, e => this.root.dispatchEvent(new CustomEvent("play-local", { detail: e }))).init();
  }
  media(name){
    const rows=this.mediaData?.[name==="radio"?"radio":"youtube"]||(name==="radio"?RADIO:YT);
    this.root.innerHTML=`<div class="panel-shell"><header><button data-close>←</button><h2>${name==="radio"?"Radio":"YT Playlist"}</h2><button class="panel-add" type="button" data-import-json aria-label="Tambah data JSON">+</button></header><div class="media-list">${rows.map((x,i)=>`<div class="media-row"><img class="list-icon" src="${x.image||""}" alt=""><button class="media-main" data-play="${i}"><strong>${x.title}</strong><small>${x.desc||""}</small></button><button class="fav-toggle" data-fav="${i}">${appState.favorites.some(f=>f.title===x.title)?"★":"☆"}</button></div>`).join("")}</div></div>`;
     this.bind(); this.root.querySelectorAll("[data-play]").forEach(b=>b.onclick=()=>{this.root.querySelectorAll("[data-play]").forEach(x=>x.classList.remove("is-active"));b.classList.add("is-active");this.root.dispatchEvent(new CustomEvent("play-media",{detail:{type:name,item:rows[+b.dataset.play]}}));});
    this.root.querySelectorAll("[data-fav]").forEach(b=>b.onclick=async()=>{await toggleFavorite({...rows[+b.dataset.fav],type:name});this.media(name);});
    this.root.querySelector("[data-import-json]").onclick=async()=>{const file=await fileSource.pickJson();if(!file)return;try{const data=JSON.parse(await file.text());const incoming=Array.isArray(data)?data:(data[name]||data.items||[]);if(!Array.isArray(incoming))throw new Error("format");const key=name==="radio"?"radio":"youtube";this.mediaData[key]=[...this.mediaData[key],...incoming.filter(x=>x.title&&!this.mediaData[key].some(y=>y.title===x.title))];this.media(name);}catch{alert("File JSON tidak sesuai format panel.");}};
  }
  saved(name){
    const rows=appState[name], label=name==="favorites"?"Favorites":"Recent", key=name==="favorites"?"favorites":"recent";
    this.root.innerHTML=`<div class="panel-shell"><header><button data-close>←</button><h2>${label}</h2><button class="panel-add" data-clear-saved aria-label="Hapus ${label}">🗑</button></header><div class="media-list">${rows.length?rows.map((x,i)=>`<button class="media-row saved-row" data-play="${i}"><img class="list-icon" src="${x.image||""}" alt=""><span class="saved-copy"><strong>${x.title}</strong><small>${x.desc||"Local music"}</small></span></button>`).join(""):"<p class=panel-hint>Belum ada data.</p>"}</div></div>`;
    this.bind();
     this.root.querySelectorAll("[data-play]").forEach(b=>b.onclick=async()=>{this.root.querySelectorAll("[data-play]").forEach(x=>x.classList.remove("is-active"));b.classList.add("is-active");const x=rows[+b.dataset.play];if(x.type==="local"){this.root.dispatchEvent(new CustomEvent("play-local",{detail:x}));return;}if(x.type==="local-video"){const files=await storage.get("local-videos",[]);const file=files.find(item=>item.name===x.title||item.name===x.name);if(file)this.root.dispatchEvent(new CustomEvent("play-local-video",{detail:{file,queue:files,index:files.indexOf(file)}}));return;}this.root.dispatchEvent(new CustomEvent("play-media",{detail:{type:x.type||"radio",item:x}}));});
    this.root.querySelector("[data-clear-saved]").onclick=async()=>{if(confirm(`Hapus semua ${label}?`)){appState[key]=[];await storage.set(key,[]);this.saved(name);}};
  }
  settings(){
    const themes=["mystic","dusk","midnight","sunrise"], eq=["flat","pop","rock","jazz","classical"];
    const current=preferences.get();
    this.root.innerHTML=`<div class="panel-shell settings-panel"><header><button data-close>←</button><h2>Settings</h2></header><div class="settings-cards">
    <section><b>Theme <em>${current.theme}</em></b><div class="choice vertical">${themes.map(x=>`<button data-theme="${x}"><span class="theme-icon theme-${x}">${({mystic:"🌌",dusk:"🌇",midnight:"🌙",sunrise:"☀️"})[x]}</span>${x}</button>`).join("")}</div></section>
    <section><b>Equalizer <em>${current.equalizer}</em></b><select class="setting-select" data-equalizer-select>${eq.map(x=>`<option value="${x}">${x}</option>`).join("")}</select><p>Radio, MP3, URL audio</p></section>
    <section><b>Sleep Timer <em>${current.sleep}</em></b><select class="setting-select" data-sleep-select><option>Off</option><option>15 min</option><option>30 min</option><option>60 min</option></select></section>
    <section><b>Volume <em>${current.volume}%</em></b><input class="setting-range" type="range" min="0" max="100" value="${current.volume}"></section>
    <section><b>Tools <em>Data</em></b><div class="tool-checklist"><label><input type="checkbox" data-tool="mp3"> Hapus list MP3</label><label><input type="checkbox" data-tool="video"> Hapus list Video</label><label><input type="checkbox" data-tool="favorites"> Reset Favorites</label><label><input type="checkbox" data-tool="recent"> Reset Recent</label><label><input type="checkbox" data-tool="cache"> Hapus cache aplikasi</label></div><button class="primary tool-delete" data-delete-selected>Hapus yang dipilih</button></section>
    </div></div>`;
    this.bind();
    this.root.querySelectorAll("[data-theme]").forEach(b=>b.onclick=()=>{document.documentElement.dataset.theme=b.dataset.theme;preferences.set("theme",b.dataset.theme);this.settings();});
    this.root.querySelector("[data-equalizer-select]").value=current.equalizer;this.root.querySelector("[data-equalizer-select]").onchange=e=>preferences.set("equalizer",e.target.value);
    this.root.querySelector("[data-sleep-select]").value=current.sleep;this.root.querySelector("[data-sleep-select]").onchange=e=>preferences.set("sleep",e.target.value);
    this.root.querySelector(".setting-range").value=current.volume;
    this.root.querySelector(".setting-range").oninput=e=>{document.querySelector("#volume").value=e.target.value;preferences.set("volume",Number(e.target.value));document.querySelector("#volume").dispatchEvent(new Event("input",{bubbles:true}));};
    this.root.querySelector("[data-delete-selected]").onclick=async()=>{const selected=[...this.root.querySelectorAll("[data-tool]:checked")].map(x=>x.dataset.tool);if(!selected.length)return;if(!confirm("Hapus data yang dipilih?"))return;if(selected.includes("mp3"))await localLibrary.clear();if(selected.includes("video"))await storage.remove("local-videos");if(selected.includes("favorites")){appState.favorites=[];await storage.set("favorites",[]);}if(selected.includes("recent")){appState.recent=[];await storage.set("recent",[]);}if(selected.includes("cache")){if(!confirm("Hapus seluruh cache aplikasi dan data lokal?"))return;localStorage.clear();await localLibrary.clear();await storage.remove("local-videos");await storage.remove("favorites");await storage.remove("recent");location.reload();return;}this.settings();};
  }
  url(){this.root.innerHTML=`<div class="panel-shell url-panel"><header><button data-close>←</button><h2>URL</h2></header><div class="body-card"><input class="url-input" data-url placeholder="https://.../stream.mp3"><button class="primary url-button" data-play-url>Putar URL</button></div></div>`;this.bind();this.root.querySelector("[data-play-url]").onclick=()=>{const u=this.root.querySelector("[data-url]").value.trim();if(u.startsWith("http://")||u.startsWith("https://"))this.root.dispatchEvent(new CustomEvent("play-url",{detail:u}));};}
  async video(){
    this.root.innerHTML=renderVideoPanel(); this.bind();
    const list=this.root.querySelector("[data-video-list]");
    const isVideo=file=>/\.(mp4|webm|ogv|mov)$/i.test(file.name||"");
    let saved=(await storage.get("local-videos",[])).filter(isVideo);
    await storage.set("local-videos",saved);
    const render=files=>{
      list.innerHTML=files.length?files.map((file,index)=>`<div class="video-item" data-video-index="${index}"><img class="list-icon video-thumb" src="${FALLBACK_ARTWORK}" alt=""><span class="local-copy"><strong>${file.name}</strong><small>Video lokal · ${(file.size/1048576).toFixed(1)} MB</small></span><span class="fav-toggle" data-video-fav aria-label="Favorite">☆</span></div>`).join(""):"<p class=panel-hint>Belum ada video lokal.</p>";
      files.forEach(async(file,index)=>{const image=list.querySelector(`[data-video-index="${index}"] .video-thumb`);if(image)image.src=await videoThumbnail(file);});
      list.querySelectorAll("[data-video-index]").forEach(row=>{
        row.onclick=event=>{if(event.target.closest("[data-video-fav]"))return;list.querySelectorAll("[data-video-index]").forEach(item=>item.classList.remove("is-active"));row.classList.add("is-active");this.root.dispatchEvent(new CustomEvent("play-local-video",{detail:{file:files[+row.dataset.videoIndex],queue:files,index:+row.dataset.videoIndex}}));};
        row.querySelector("[data-video-fav]").onclick=async event=>{event.stopPropagation();const file=files[+row.dataset.videoIndex];await toggleFavorite({id:`video:${file.name}:${file.size}`,title:file.name,desc:"Video lokal",type:"local-video"});event.currentTarget.textContent=appState.favorites.some(item=>item.id===`video:${file.name}:${file.size}`)?"★":"☆";};
      });
    };
    render(saved);
    const picker=this.root.querySelector("[data-pick-video-files]");
    picker.onclick=async event=>{event.preventDefault();event.stopPropagation();try{const files=(await (fileSource.pickVideoFiles?.()||fileSource.pickVideoFolder())).filter(isVideo);if(!files.length)return;saved=[...saved,...files.filter(file=>!saved.some(item=>item.name===file.name&&item.size===file.size))];await storage.set("local-videos",saved);render(saved);}catch(error){if(error?.name!=="AbortError")list.innerHTML="<p class=panel-hint>Video tidak dapat dibuka.</p>";}};
  }
  search(){this.root.innerHTML=`<div class="panel-shell search-panel"><header><button data-close>←</button><h2>Search</h2></header><input class="search-input" data-search placeholder="Search YT, Radio, MP3"><div class="media-list" data-results></div></div>`;this.bind();const i=this.root.querySelector("[data-search]"),o=this.root.querySelector("[data-results]"),a=[...(this.mediaData?.radio||RADIO).map(x=>({...x,type:"radio"})),...(this.mediaData?.youtube||YT).map(x=>({...x,type:"yt"}))];i.oninput=()=>{const rows=a.filter(x=>`${x.title} ${x.desc||""}`.toLowerCase().includes(i.value.toLowerCase()));o.innerHTML=rows.map((x,n)=>`<button class="media-row" data-result="${n}"><strong>${x.title}</strong><small>${x.desc||""}</small></button>`).join("")||"<p class=panel-hint>Tidak ada hasil.</p>";o.querySelectorAll("[data-result]").forEach(b=>b.onclick=()=>{const x=rows[+b.dataset.result];this.root.dispatchEvent(new CustomEvent("play-media",{detail:{type:x.type,item:x}}));});};}
}
