import * as bridge from "../bridge/ria-bridge.js";
import * as uds from "../storage/user-data-storage.js";

const listeners = new Set();
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit() { const s = getState(); listeners.forEach(fn => { try { fn(s); } catch {} }); }

let audioCtx = null, analyser = null, sourceNode = null, destination = null, frequency = null;
let recorder = null, chunks = [], timer = null, startedAt = 0, station = "";
let autoStopMs = 0, autoStopTimer = null;
let recordings = [];
let loaded = false;

export function getState() {
  return {
    recording: recorder?.state === "recording",
    elapsedMs: recorder?.state === "recording" ? (Date.now() - startedAt) : 0,
    station,
    autoStopMs,
    recordings: [...recordings],
    ready: !!destination,
    supported: typeof MediaRecorder !== "undefined",
  };
}

export async function loadRecordings() {
  if (loaded) return recordings;
  const list = await uds.readJson("recordings.json", []);
  recordings = Array.isArray(list) ? list : [];
  loaded = true;
  return recordings;
}
async function saveRecordings() {
  try { await uds.writeJson("recordings.json", recordings); } catch {}
}

export function setAutoStopMs(ms) {
  autoStopMs = Math.max(0, Number(ms) || 0);
  // reschedule if recording
  if (autoStopTimer) { clearTimeout(autoStopTimer); autoStopTimer = null; }
  if (recorder?.state === "recording" && autoStopMs > 0) {
    const remaining = autoStopMs - (Date.now() - startedAt);
    if (remaining <= 0) stop();
    else autoStopTimer = setTimeout(() => { if (recorder?.state === "recording") stop(); }, remaining);
  }
  emit();
}
export function getAutoStopMs() { return autoStopMs; }

export function prepare(streamAudioEl, bars) {
  if (analyser) return true;
  try {
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
    audioCtx = new AC();
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 64;
    analyser.smoothingTimeConstant = .72;
    sourceNode = audioCtx.createMediaElementSource(streamAudioEl);
    sourceNode.connect(analyser);
    analyser.connect(audioCtx.destination);
    destination = audioCtx.createMediaStreamDestination();
    analyser.connect(destination);
    frequency = new Uint8Array(analyser.frequencyBinCount);
    const draw = () => {
      try {
        const stage = document.querySelector("#player-stage");
        if (analyser && stage?.dataset.mode === "radio" && !streamAudioEl.paused) {
          analyser.getByteFrequencyData(frequency);
          (bars || []).forEach((bar, i) => { const group = i < 48 ? Math.floor(i / 3) : 15 - Math.floor((i - 48) / 3), side = 1.15 - (group / 15) * .6; bar.style.height = `${Math.min(150, 12 + (frequency[group % frequency.length] || 0) * .57 * side)}px`; });
        } else if (stage?.dataset.mode === "radio") (bars || []).forEach(bar => bar.style.height = "12px");
      } catch {}
      requestAnimationFrame(draw);
    };
    draw();
    emit();
    return true;
  } catch { return false; }
}

export function resume() { try { audioCtx?.resume?.(); } catch {} }

function stopTimer() { if (timer) { clearInterval(timer); timer = null; } }
function stopAutoStop() { if (autoStopTimer) { clearTimeout(autoStopTimer); autoStopTimer = null; } }

export async function start(stationName = "") {
  if (recorder?.state === "recording") return { ok: false, error: "Sedang merekam." };
  if (typeof MediaRecorder === "undefined") return { ok: false, error: "Perekaman tidak didukung di perangkat ini." };
  if (!destination) return { ok: false, error: "Perekam belum siap. Putar radio terlebih dahulu." };
  chunks = [];
  station = String(stationName || "").trim();
  const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : (MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "");
  try {
    recorder = new MediaRecorder(destination.stream, mime ? { mimeType: mime } : undefined);
  } catch (e) {
    emit();
    return { ok: false, error: "Perekaman tidak dapat dimulai (mungkin dibatasi oleh sumber/CORS)." };
  }
  recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
  recorder.onerror = () => { stopTimer(); stopAutoStop(); emit(); };
  recorder.onstop = async () => {
    stopTimer(); stopAutoStop();
    const recStation = station;
    const durationMs = Date.now() - startedAt;
    if (!chunks.length) { emit(); return; }
    const type = recorder.mimeType || "audio/webm";
    const ext = type.includes("ogg") ? "ogg" : "webm";
    const blob = new Blob(chunks, { type });
    const stamp = new Date();
    const pad = n => String(n).padStart(2, "0");
    const name = `RiaMusic-Radio-${stamp.getFullYear()}${pad(stamp.getMonth()+1)}${pad(stamp.getDate())}-${pad(stamp.getHours())}${pad(stamp.getMinutes())}${pad(stamp.getSeconds())}.${ext}`;
    const data = await new Promise(resolve => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => resolve(null); reader.readAsDataURL(blob); });
    if (!data) { emit(); return; }
    let saved = null;
    try { saved = await bridge.saveRecording(name, data); } catch {}
    const entry = {
      id: `rec-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,
      name,
      title: recStation ? `${recStation} - ${pad(stamp.getHours())}:${pad(stamp.getMinutes())}` : name.replace(/\.[^.]+$/, ""),
      station: recStation,
      createdAt: Date.now(),
      durationMs,
      mime: type,
      size: blob.size,
      path: saved?.path || null,
      uri: saved?.uri || null,
      playableUri: saved?.playableUri || null,
      ok: !!(saved && (saved.ok === true || saved.path || saved.uri)),
    };
    // if not saved natively, keep blob for in-app playback (web fallback) in memory? not persisted
    if (!entry.ok) { entry.blobUrl = URL.createObjectURL(blob); entry._blob = blob; }
    recordings = [entry, ...recordings].slice(0, 200);
    try { await saveRecordings(); } catch {}
    emit();
  };
  try { recorder.start(1000); } catch { recorder = null; emit(); return { ok: false, error: "Perekaman tidak dapat dimulai (mungkin dibatasi oleh sumber/CORS)." }; }
  startedAt = Date.now();
  stopAutoStop();
  if (autoStopMs > 0) autoStopTimer = setTimeout(() => { if (recorder?.state === "recording") stop(); }, autoStopMs);
  stopTimer();
  timer = setInterval(() => emit(), 1000);
  emit();
  return { ok: true };
}

export function stop() {
  if (recorder?.state !== "recording") return { ok: false };
  try { recorder.stop(); } catch {}
  stopTimer(); stopAutoStop();
  emit();
  return { ok: true };
}

export function toggle(stationName = "") {
  if (recorder?.state === "recording") return stop();
  return start(stationName);
}

export async function removeRecording(id) {
  const idx = recordings.findIndex(r => r.id === id);
  if (idx < 0) return;
  const [rec] = recordings.splice(idx, 1);
  try { if (rec?.blobUrl) URL.revokeObjectURL(rec.blobUrl); } catch {}
  await saveRecordings();
  emit();
}

export async function clearRecordings() {
  recordings.forEach(r => { try { if (r?.blobUrl) URL.revokeObjectURL(r.blobUrl); } catch {} });
  recordings = [];
  await saveRecordings();
  emit();
}

export function getPlayableSrc(rec) {
  if (!rec) return null;
  if (rec.playableUri) return bridge.resolvePlayableUri(rec.playableUri);
  if (rec.uri) return bridge.resolvePlayableUri(rec.uri);
  if (rec.blobUrl) return rec.blobUrl;
  return null;
}
