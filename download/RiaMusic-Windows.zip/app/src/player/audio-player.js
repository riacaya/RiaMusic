export class AudioPlayer {
  constructor(audio, ui = {}) {
    this.audio = audio;
    this.playButton = ui.playButton;
    this.muteButton = ui.muteButton;
    this.volume = ui.volume;
    this.bars = ui.bars || [];
    this.analyser = null;
    this.audioContext = null;
    this.playButton?.addEventListener("click", () => this.toggle());
    this.muteButton?.addEventListener("click", () => this.toggleMute());
    this.volume?.addEventListener("input", event => this.setVolume(event.target.value));
    this.audio.addEventListener("play", () => this.update(true));
    this.audio.addEventListener("pause", () => this.update(false));
  }

  async playFile(file) {
    if (!file) return;
    const uri = typeof file === "string" ? file : file.uri;
    const resolveUri = (typeof window !== "undefined" && window.RiaBridge?.resolvePlayableUri)
      ? (u) => window.RiaBridge.resolvePlayableUri(u)
      : ((typeof window !== "undefined" && window.Capacitor?.convertFileSrc) ? (u) => window.Capacitor.convertFileSrc(u) : (u) => u);
    this.audio.src = uri ? resolveUri(uri) : URL.createObjectURL(file);
    this.prepareAnalyser();
    await this.audio.play();
  }

  async toggle() {
    if (!this.audio.src) return;
    if (this.audio.paused) await this.audio.play();
    else this.audio.pause();
  }

  toggleMute() {
    this.audio.muted = !this.audio.muted;
    if (this.muteButton) this.muteButton.textContent = this.audio.muted ? "🔇" : "🔊";
  }

  setVolume(value) { this.audio.volume = Number(value) / 100; }
  update(playing) { if (this.playButton) this.playButton.textContent = playing ? "❚❚" : "▶"; }

  prepareAnalyser(){
    if(this.analyser||!(window.AudioContext||window.webkitAudioContext))return;
    try{const C=window.AudioContext||window.webkitAudioContext;const ctx=new C();this.audioContext=ctx;const source=ctx.createMediaElementSource(this.audio);this.analyser=ctx.createAnalyser();this.analyser.fftSize=64;source.connect(this.analyser);this.analyser.connect(ctx.destination);this.draw();}catch{}
  }
  startVisualiser(){this.prepareAnalyser()}
  resumeContext(){return this.audioContext?.resume?.()}
  draw(){if(!this.analyser)return;const data=new Uint8Array(this.analyser.frequencyBinCount);const tick=()=>{if(this.audio.paused){this.bars.forEach(bar=>bar.style.height="12px");requestAnimationFrame(tick);return}this.analyser.getByteFrequencyData(data);this.bars.forEach((bar,i)=>{const group=i<48?Math.floor(i/3):15-Math.floor((i-48)/3),value=data[group%data.length]||0,side=1.15-(group/15)*.6;bar.style.height=`${Math.min(150,12+value*.57*side)}px`});requestAnimationFrame(tick)};tick()}
}
