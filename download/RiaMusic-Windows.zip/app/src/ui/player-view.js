export function renderHeader(root) {
  root.innerHTML = `<div class="brand"><img id="logo" alt="RiaMusic" src="./src/assets/ria-music.svg"><div class="brand-text"><h1>RiaMusic</h1><p>After The Silent</p></div></div><div class="top-actions"><button class="icon-btn" data-action="queue" aria-label="Daftar Putar">📄</button><button class="icon-btn" data-action="menu" aria-label="Menu">&#8942;</button><button class="icon-btn apk-rail-btn" data-action="open-rail" aria-label="Menu navigasi">&#9776;</button></div>`;
}

export function renderRailHeader(root) {
  if (!root) return;
  root.innerHTML = `<button class="rail-menu-toggle" data-action="rail-toggle" title="Menu" aria-label="Menu"><span class="rail-icon">☰</span><span class="rail-header-label">Menu</span></button>`;
}

export function renderRail(root) {
  if (!root) return;
  const isApk = typeof document !== "undefined" && document.body?.classList.contains("is-apk");
  const header = isApk ? `<header class="panel-header rail-drawer-header"><span></span><h2><span class="panel-title-icon" aria-hidden="true">☰</span>Menu</h2><button type="button" class="rail-drawer-close" data-action="close-rail" aria-label="Tutup">×</button></header>` : "";
  root.innerHTML = `${header}<div class="rail-inner">
    <button class="rail-btn" data-action="add-local" title="Tambah file lokal" aria-label="Tambah file lokal"><span class="rail-icon">+</span><span class="rail-label">Tambah</span></button>
    <button class="rail-btn" data-open="library" data-tab="mp3" title="Playlist" aria-label="Playlist"><span class="rail-icon">♫</span><span class="rail-label">Playlist</span></button>
    <button class="rail-btn" data-open="overlay" data-overlay="settings" title="Settings" aria-label="Settings"><span class="rail-icon">⚙</span><span class="rail-label">Settings</span></button>
    <button class="rail-btn desktop-record" data-open="overlay" data-overlay="record" title="Record" aria-label="Record"><span class="rail-icon">●</span><span class="rail-label">Record</span></button>
    <button class="rail-btn" data-open="overlay" data-overlay="url" title="URL" aria-label="URL"><span class="rail-icon">🔗</span><span class="rail-label">URL</span></button>
    <button class="rail-btn" data-open="overlay" data-overlay="guide" title="Panduan" aria-label="Panduan"><span class="rail-icon">📖</span><span class="rail-label">Panduan</span></button>
    <button class="rail-btn" data-open="overlay" data-overlay="about" title="About" aria-label="About"><span class="rail-icon">ⓘ</span><span class="rail-label">About</span></button>
  </div>`;
}

export function renderPlayer(root) {
  root.innerHTML = `<div class="backdrop" id="backdrop"></div>
    <video class="media" id="video" playsinline webkit-playsinline></video>
    <iframe class="media" id="yt" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen title="YouTube player"></iframe>
    <div class="source-info" id="sourceInfo"><img id="sourceIcon" alt=""><div><strong id="sourceTitle"></strong><small id="sourceDesc"></small></div></div>
    <div class="now"><div class="weather" id="weather"><div id="city">Detecting location</div><div><span id="weatherText">Loading weather</span> <span id="clock">--:--</span></div></div>
      <div class="disc"><img id="cover" alt="cover" src="./src/assets/ria-music.svg"></div>
      <h2 class="title" id="title">RiaMusic</h2><p class="desc" id="desc">Ready to play</p><div class="eq" id="eq">${Array.from({length:96},(_,i)=>`<span style="--n:${i}"></span>`).join("")}</div>
    </div>
    <div class="controls"><button class="ctrl radio-record" data-action="record" aria-label="Record radio" title="Record radio">●</button><button class="ctrl" data-action="shuffle">&#8644;</button><button class="ctrl" data-action="previous">&#9198;</button><button class="ctrl play" id="play" data-action="toggle">&#9654;</button><button class="ctrl" data-action="next">&#9197;</button><button class="ctrl" data-action="repeat">&#8635;</button><div class="vol"><button class="ctrl" data-action="mute" id="mute">&#128266;</button><input id="volume" type="range" min="0" max="100" value="82"></div></div>
    <audio id="audio" playsinline></audio><audio id="streamAudio" playsinline crossorigin="anonymous"></audio>`;
}
