import { subscribe, getState, clearQueue, setIndex, saveQueueAsPlaylist } from "../queue.js?v=20261120w";

export class QueuePanel {
  constructor(root, headerRoot = null) {
    this.root = root;
    this.headerRoot = headerRoot;
    this.onPlayAt = null; // (index, item) => void
    this.filter = "";
    subscribe(() => this.render());
  }

  mount() { this.render(); }

  renderHeader() {
    if (!this.headerRoot) return;
    this.headerRoot.innerHTML = `<div class="queue-header-search"><span class="queue-search-icon">🔍</span><input type="search" data-queue-search placeholder="Pencarian" value="${this.filter.replace(/"/g, "&quot;")}"></div>`;
    const search = this.headerRoot.querySelector("[data-queue-search]");
    if (search) {
      search.addEventListener("input", () => {
        const val = search.value;
        const pos = search.selectionStart ?? val.length;
        this.filter = val;
        this.render();
        const s = this.headerRoot?.querySelector("[data-queue-search]");
        if (s) { s.focus(); try { s.setSelectionRange(pos, pos); } catch {} }
      });
    }
  }

  render() {
    if (!this.root) return;
    this.renderHeader();
    const isMobilePanel = !this.headerRoot;
    const { items, index } = getState();
    const q = (this.filter || "").toLowerCase().trim();
    const filtered = q ? items.map((item, i) => ({ item, i })).filter(({ item }) => {
      const text = `${item.title || item.name || ""} ${item.desc || item.path || ""}`.toLowerCase();
      return text.includes(q);
    }) : items.map((item, i) => ({ item, i }));
    const rows = filtered.length ? filtered.map(({ item, i }) => {
      const active = i === index ? " is-active" : "";
      const title = (item.title || item.name || "Item").replace(/</g, "&lt;");
      const sub = (item.desc || item.path || item.type || "").toString().replace(/</g, "&lt;");
      return `<button class="queue-item${active}" data-q-index="${i}"><span class="q-num">${i + 1}</span><span class="q-copy"><strong>${title}</strong><small>${sub}</small></span></button>`;
    }).join("") : `<p class="panel-hint queue-empty">${q ? "Tidak ada hasil." : "Daftar putar kosong. Pilih sumber dan putar lagu untuk mengisi."}</p>`;

    const panelHeader = isMobilePanel ? `<header class="panel-header queue-panel-header"><button type="button" data-q-close aria-label="Kembali">&larr;</button><h2><span class="panel-title-icon" aria-hidden="true">📄</span>Daftar Putar</h2><span></span></header>` : "";
    this.root.innerHTML = `<div class="queue-shell panel-shell">${panelHeader}<div class="queue-top"><span class="queue-label">Daftar</span><button type="button" class="queue-action" data-q-clear ${items.length ? "" : "disabled"}>Kosongkan</button><button type="button" class="queue-action" data-q-save ${items.length ? "" : "disabled"}>Simpan</button></div><div class="queue-list">${rows}</div></div>`;

    // fallback: if no separate header root, keep search inside body (mobile/APK)
    if (isMobilePanel) {
      const shell = this.root.querySelector(".queue-shell");
      if (shell) {
        const after = shell.querySelector(".queue-panel-header");
        const searchHtml = `<div class="queue-search"><span class="queue-search-icon">🔍</span><input type="search" data-queue-search placeholder="Pencarian" value="${this.filter.replace(/"/g, "&quot;")}"></div>`;
        if (after) after.insertAdjacentHTML("afterend", searchHtml); else shell.insertAdjacentHTML("afterbegin", searchHtml);
        const search = this.root.querySelector("[data-queue-search]");
        if (search) {
          search.addEventListener("input", () => {
            const val = search.value;
            const pos = search.selectionStart ?? val.length;
            this.filter = val;
            this.render();
            const s = this.root.querySelector("[data-queue-search]");
            if (s) { s.focus(); try { s.setSelectionRange(pos, pos); } catch {} }
          });
        }
      }
      this.root.querySelector("[data-q-close]")?.addEventListener("click", () => {
        this.root.classList.remove("show");
      });
    }

    this.root.querySelector("[data-q-clear]")?.addEventListener("click", () => {
      if (!items.length) return;
      if (typeof confirm !== "function" || confirm("Kosongkan daftar putar?")) clearQueue();
    });
    this.root.querySelector("[data-q-save]")?.addEventListener("click", async () => {
      if (!items.length) return;
      const name = (typeof prompt === "function") ? prompt("Nama playlist:", "Daftar Putar") : null;
      if (!name) return;
      try { await saveQueueAsPlaylist(name.trim() || "Daftar Putar"); } catch {}
    });
    this.root.querySelectorAll("[data-q-index]").forEach(btn => btn.addEventListener("click", () => {
      const i = Number(btn.dataset.qIndex);
      const item = items[i];
      if (!item) return;
      setIndex(i);
      if (this.onPlayAt) this.onPlayAt(i, item);
    }));
  }
}

















