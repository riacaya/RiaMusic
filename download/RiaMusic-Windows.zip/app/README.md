# RiaMusic Next

Struktur pengembangan terpisah dari `../riamusic.html`. File referensi asli tidak diubah.

Tahap awal hanya memisahkan penyimpanan lokal untuk pustaka MP3. UI dan player akan dihubungkan pada tahap berikutnya.

## Menjalankan prototipe

Buka `index.html` melalui server lokal, bukan `file://`, karena ES module dan IndexedDB memerlukan origin. Contoh:

```text
python -m http.server 8080 -d riamusic-next
```

Lalu buka `http://localhost:8080`.

Atau jalankan `../jalankan-riamusic.bat` dengan klik dua kali.

## Struktur

```text
riamusic-next/
├── README.md
└── src/
    ├── app.js
    ├── mp3/
    │   ├── local-library.js
    │   └── local-panel.js
    └── storage/
        ├── storage-contract.js
        ├── browser-storage.js
        ├── file-source.js
        ├── browser-file-source.js
        └── indexed-db-storage.js
```

## Rencana platform

- PC/browser: File System Access API atau file picker.
- Android/APK: adapter native akan menggantikan adapter browser tanpa mengubah modul pustaka.
- Metadata lagu disimpan, sedangkan file audio tetap berada di perangkat pengguna.
- Link radio dapat diedit di `data/radio.json`.
- Link playlist YouTube dapat diedit di `data/youtube.json`.
- `BrowserFileSource` mendukung pilih banyak file dan pilih folder/subfolder.
- `NativeFileSource` disiapkan untuk bridge Capacitor/Android/Windows.
