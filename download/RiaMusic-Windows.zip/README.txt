RiaMusic for Windows (WebView2)
- Jalankan RiaMusic.exe
- Prasyarat: WebView2 Runtime (umumnya sudah ada di Windows 10/11) dan .NET Framework 4.x
- Data/playlist disimpan lokal di %LOCALAPPDATA%\RiaMusic\WebView2
