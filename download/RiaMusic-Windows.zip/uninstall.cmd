@echo off
setlocal
set "TARGET=%LOCALAPPDATA%\Programs\RiaMusic"
taskkill /IM RiaMusic.exe /F >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop'); Remove-Item (Join-Path $d 'RiaMusic.lnk') -Force -ErrorAction SilentlyContinue;" ^
  "$sm=[Environment]::GetFolderPath('StartMenu'); Remove-Item (Join-Path $sm 'Programs\RiaMusic') -Recurse -Force -ErrorAction SilentlyContinue"
if exist "%TARGET%" rmdir /S /Q "%TARGET%"
echo RiaMusic dihapus.
pause
