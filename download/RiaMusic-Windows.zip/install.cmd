@echo off
setlocal
set "TARGET=%LOCALAPPDATA%\Programs\RiaMusic"
if not exist "%TARGET%" mkdir "%TARGET%"
echo Menyalin file ke %TARGET% ...
robocopy "%~dp0." "%TARGET%" /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NP >nul
if %ERRORLEVEL% GEQ 8 (
  echo Gagal menyalin file.
  exit /b %ERRORLEVEL%
)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "$d=[Environment]::GetFolderPath('Desktop');" ^
  "$s=$ws.CreateShortcut((Join-Path $d 'RiaMusic.lnk')); $s.TargetPath='%TARGET%\RiaMusic.exe'; $s.WorkingDirectory='%TARGET%'; $s.IconLocation='%TARGET%\RiaMusic.exe,0'; $s.Save();" ^
  "$sm=[Environment]::GetFolderPath('StartMenu'); $p=Join-Path $sm 'Programs\RiaMusic'; New-Item -ItemType Directory -Force -Path $p|Out-Null;" ^
  "$s2=$ws.CreateShortcut((Join-Path $p 'RiaMusic.lnk')); $s2.TargetPath='%TARGET%\RiaMusic.exe'; $s2.WorkingDirectory='%TARGET%'; $s2.IconLocation='%TARGET%\RiaMusic.exe,0'; $s2.Save()"
echo.
echo RiaMusic terinstal di: %TARGET%
echo Shortcut dibuat di Desktop dan Start Menu.
start "" "%TARGET%\RiaMusic.exe"
